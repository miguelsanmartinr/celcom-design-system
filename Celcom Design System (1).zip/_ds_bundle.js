/* @ds-bundle: {"format":4,"namespace":"CelcomDesignSystem_4f9867","components":[{"name":"DesignSystem","sourcePath":"celcom-design-system.jsx"}],"sourceHashes":{"celcom-design-system.jsx":"7693ea89911a","doc-page.js":"371bab66f42d","ui_kits/platform/ChatbotPages.jsx":"8f4162d9d57a","ui_kits/platform/Dashboard.jsx":"f21f7f60a52c","ui_kits/platform/ExtraScreens.jsx":"e1a205a33698","ui_kits/platform/Screens.jsx":"a920cea3de9d","ui_kits/platform/Sidebar.jsx":"e53e4b0257ee","ui_kits/website/ClientesCarousel.jsx":"13c8a93eb8bb","ui_kits/website/Formulario.jsx":"27058cd7e52b","ui_kits/website/Header.jsx":"c8ad3568f19e","ui_kits/website/Hero.jsx":"f1cd3add8a59","ui_kits/website/QuienesSomos.jsx":"52060fa8b69b","ui_kits/website/ServiciosTabs.jsx":"08261fea7b46"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CelcomDesignSystem_4f9867 = window.CelcomDesignSystem_4f9867 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// celcom-design-system.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React; // ============================================================
// CELCOM LATAM — DESIGN SYSTEM v1.1
// celcomlatam.com · Actualizado Abril 2026
// ============================================================
const tokens = {
  colors: {
    brand: {
      primary: "#0057B8",
      primaryDark: "#003D82",
      primaryLight: "#3A82D4",
      secondary: "#001F5B",
      accent: "#FFB800",
      // ← Amarillo Celcom
      accentDark: "#CC9200",
      accentLight: "#FFD966"
    },
    neutral: {
      white: "#FFFFFF",
      50: "#FAFBFF",
      100: "#F4F6FB",
      200: "#E8EDF5",
      300: "#C7D2E6",
      400: "#9AACC8",
      500: "#7A8EAD",
      700: "#3A4A6B",
      900: "#0D1B33"
    },
    semantic: {
      success: "#22C55E",
      warning: "#F59E0B",
      error: "#EF4444",
      info: "#3A82D4"
    },
    channels: {
      whatsapp: "#25D366",
      sms: "#0057B8",
      email: "#FFB800",
      chatbot: "#8B5CF6"
    }
  },
  typography: {
    families: {
      heading: "'Poppins','Montserrat',sans-serif",
      body: "'Inter','Open Sans',sans-serif",
      mono: "'Fira Code',monospace"
    },
    scale: {
      "2xs": "0.625rem",
      xs: "0.75rem",
      sm: "0.875rem",
      base: "1rem",
      lg: "1.125rem",
      xl: "1.25rem",
      "2xl": "1.5rem",
      "3xl": "1.875rem",
      "4xl": "2.25rem",
      "5xl": "3rem"
    },
    weights: {
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800
    },
    lineHeights: {
      tight: 1.2,
      normal: 1.5,
      relaxed: 1.75
    }
  },
  spacing: {
    1: "4px",
    2: "8px",
    3: "12px",
    4: "16px",
    5: "20px",
    6: "24px",
    8: "32px",
    10: "40px",
    12: "48px",
    16: "64px",
    20: "80px"
  },
  radii: {
    none: "0",
    sm: "4px",
    md: "8px",
    lg: "12px",
    xl: "16px",
    "2xl": "24px",
    full: "9999px"
  },
  shadows: {
    xs: "0 1px 2px rgba(0,0,0,0.06)",
    sm: "0 1px 3px rgba(0,0,0,0.08)",
    md: "0 4px 12px rgba(0,87,184,0.10)",
    lg: "0 8px 24px rgba(0,87,184,0.14)",
    xl: "0 16px 48px rgba(0,87,184,0.18)",
    accent: "0 4px 16px rgba(255,184,0,0.30)"
  },
  motion: {
    fast: "150ms ease",
    normal: "250ms ease",
    slow: "400ms ease-in-out"
  }
};
const T = tokens;
const C = T.colors;
const navItems = ["Tokens", "Tipografía", "Componentes", "SaaS", "Patrones", "Canales"];

// ─── HELPERS ──────────────────────────────────────────────
function Section({
  title,
  subtitle,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 56
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: T.typography.scale["2xl"],
      fontWeight: T.typography.weights.bold,
      color: C.neutral[900],
      margin: "0 0 4px"
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.neutral[500],
      fontSize: T.typography.scale.sm,
      margin: "0 0 28px"
    }
  }, subtitle), children);
}
function Grid({
  cols = 3,
  gap = 16,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${cols},1fr)`,
      gap
    }
  }, children);
}
function Card({
  children,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral.white,
      border: `1px solid ${C.neutral[200]}`,
      borderRadius: T.radii.lg,
      padding: 20,
      ...style
    }
  }, children);
}
function Label({
  children,
  color = C.neutral[500]
}) {
  return /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color,
      fontWeight: T.typography.weights.semibold,
      textTransform: "uppercase",
      letterSpacing: "0.06em",
      margin: "0 0 10px"
    }
  }, children);
}
function Chip({
  children,
  color = C.brand.primary,
  bg
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "3px 10px",
      borderRadius: T.radii.full,
      background: bg || color + "18",
      color,
      fontSize: T.typography.scale.xs,
      fontWeight: T.typography.weights.semibold
    }
  }, children);
}
function Divider() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: C.neutral[200],
      margin: "28px 0"
    }
  });
}

// ─── BUTTONS ──────────────────────────────────────────────
function Btn({
  variant = "primary",
  size = "md",
  children,
  disabled,
  icon,
  fullWidth
}) {
  const vs = {
    primary: {
      bg: C.brand.primary,
      text: "#fff",
      border: C.brand.primary
    },
    accent: {
      bg: C.brand.accent,
      text: C.brand.secondary,
      border: C.brand.accent
    },
    secondary: {
      bg: "transparent",
      text: C.brand.primary,
      border: C.brand.primary
    },
    ghost: {
      bg: "transparent",
      text: C.neutral[700],
      border: C.neutral[300]
    },
    danger: {
      bg: C.semantic.error,
      text: "#fff",
      border: C.semantic.error
    },
    dark: {
      bg: C.brand.secondary,
      text: "#fff",
      border: C.brand.secondary
    }
  };
  const sz = {
    xs: {
      px: "10px",
      py: "5px",
      fs: T.typography.scale.xs
    },
    sm: {
      px: "14px",
      py: "7px",
      fs: T.typography.scale.sm
    },
    md: {
      px: "20px",
      py: "10px",
      fs: T.typography.scale.base
    },
    lg: {
      px: "28px",
      py: "13px",
      fs: T.typography.scale.lg
    }
  };
  const s = vs[variant];
  const z = sz[size];
  return /*#__PURE__*/React.createElement("button", {
    style: {
      background: disabled ? C.neutral[200] : s.bg,
      color: disabled ? C.neutral[400] : s.text,
      border: `2px solid ${disabled ? C.neutral[200] : s.border}`,
      padding: `${z.py} ${z.px}`,
      fontSize: z.fs,
      fontWeight: T.typography.weights.semibold,
      fontFamily: T.typography.families.body,
      borderRadius: T.radii.md,
      cursor: disabled ? "not-allowed" : "pointer",
      transition: T.motion.fast,
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      width: fullWidth ? "100%" : undefined,
      justifyContent: fullWidth ? "center" : undefined
    }
  }, icon && /*#__PURE__*/React.createElement("span", null, icon), children);
}

// ─── TOKENS TAB ───────────────────────────────────────────
function ColorSwatch({
  name,
  hex,
  textColor = "#fff"
}) {
  const [copied, setCopied] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: T.radii.md,
      overflow: "hidden",
      boxShadow: T.shadows.sm,
      cursor: "pointer"
    },
    onClick: () => {
      navigator.clipboard?.writeText(hex);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: hex,
      height: 60,
      display: "flex",
      alignItems: "flex-end",
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "10px",
      color: textColor,
      opacity: 0.85
    }
  }, copied ? "✓ copiado" : hex)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral.white,
      padding: "8px 10px",
      borderTop: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[700],
      fontWeight: 600,
      margin: 0
    }
  }, name)));
}
function TokensTab() {
  const groups = [{
    label: "Marca",
    cols: 7,
    items: [{
      name: "Primary",
      hex: C.brand.primary
    }, {
      name: "Primary Dark",
      hex: C.brand.primaryDark
    }, {
      name: "Primary Light",
      hex: C.brand.primaryLight
    }, {
      name: "Secondary",
      hex: C.brand.secondary
    }, {
      name: "Accent ★",
      hex: C.brand.accent,
      textColor: C.brand.secondary
    }, {
      name: "Accent Dark",
      hex: C.brand.accentDark,
      textColor: C.brand.secondary
    }, {
      name: "Accent Light",
      hex: C.brand.accentLight,
      textColor: C.brand.secondary
    }]
  }, {
    label: "Neutral",
    cols: 7,
    items: [{
      name: "White",
      hex: C.neutral.white,
      textColor: "#ccc"
    }, {
      name: "50",
      hex: C.neutral[50],
      textColor: "#aaa"
    }, {
      name: "100",
      hex: C.neutral[100],
      textColor: "#999"
    }, {
      name: "200",
      hex: C.neutral[200],
      textColor: "#888"
    }, {
      name: "300",
      hex: C.neutral[300]
    }, {
      name: "500",
      hex: C.neutral[500]
    }, {
      name: "900",
      hex: C.neutral[900]
    }]
  }, {
    label: "Semánticos",
    cols: 4,
    items: [{
      name: "Success",
      hex: C.semantic.success
    }, {
      name: "Warning",
      hex: C.semantic.warning,
      textColor: C.brand.secondary
    }, {
      name: "Error",
      hex: C.semantic.error
    }, {
      name: "Info",
      hex: C.semantic.info
    }]
  }, {
    label: "Canales",
    cols: 4,
    items: [{
      name: "WhatsApp",
      hex: C.channels.whatsapp
    }, {
      name: "SMS",
      hex: C.channels.sms
    }, {
      name: "Email",
      hex: C.channels.email,
      textColor: C.brand.secondary
    }, {
      name: "Chatbot",
      hex: C.channels.chatbot
    }]
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: `linear-gradient(135deg,${C.brand.accent} 0%,${C.brand.accentLight} 100%)`,
      borderRadius: T.radii.xl,
      padding: "20px 24px",
      marginBottom: 32,
      display: "flex",
      alignItems: "center",
      gap: 16,
      boxShadow: T.shadows.accent
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      background: "rgba(0,0,0,0.12)",
      borderRadius: T.radii.lg,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 28
    }
  }, "\u2605"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 800,
      fontSize: T.typography.scale.lg,
      color: C.brand.secondary,
      margin: "0 0 2px"
    }
  }, "Amarillo Celcom \u2014 #FFB800"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.brand.secondary,
      opacity: 0.7,
      margin: 0
    }
  }, "Color de acento principal. Uso en CTAs secundarios, highlights, iconograf\xEDa y elementos de \xE9nfasis.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      gap: 8
    }
  }, [C.brand.accent, C.brand.accentDark, C.brand.accentLight].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 40,
      height: 40,
      background: h,
      borderRadius: T.radii.full,
      border: "2px solid rgba(0,0,0,0.1)"
    }
  })))), /*#__PURE__*/React.createElement(Section, {
    title: "Paleta de Colores",
    subtitle: "Clic en cualquier muestra para copiar el HEX."
  }, groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.label,
    style: {
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(Label, null, g.label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${g.cols},1fr)`,
      gap: 10
    }
  }, g.items.map(s => /*#__PURE__*/React.createElement(ColorSwatch, _extends({
    key: s.name
  }, s))))))), /*#__PURE__*/React.createElement(Section, {
    title: "Espaciado",
    subtitle: "Escala basada en m\xFAltiplos de 4px."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 12,
      alignItems: "flex-end"
    }
  }, Object.entries(T.spacing).map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.brand.primaryLight,
      width: v,
      height: v,
      borderRadius: 4,
      margin: "0 auto 4px"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: C.neutral[500],
      margin: "0 0 1px"
    }
  }, k), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: C.neutral[700],
      fontWeight: 600,
      margin: 0
    }
  }, v))))), /*#__PURE__*/React.createElement(Grid, {
    cols: 2,
    gap: 24
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Border Radius",
    subtitle: "Curvaturas del sistema."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 14,
      alignItems: "center"
    }
  }, Object.entries(T.radii).map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      background: `${C.brand.primary}18`,
      border: `2px solid ${C.brand.primary}`,
      borderRadius: v
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: C.neutral[500],
      marginTop: 4
    }
  }, k), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: C.neutral[700],
      fontWeight: 600
    }
  }, v))))), /*#__PURE__*/React.createElement(Section, {
    title: "Sombras",
    subtitle: "Niveles de elevaci\xF3n."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, Object.entries(T.shadows).map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      background: C.neutral.white,
      borderRadius: T.radii.md,
      boxShadow: v,
      padding: "10px 16px",
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      fontWeight: 600,
      color: C.neutral[700]
    }
  }, "shadow-", k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[400]
    }
  }, v.slice(0, 32), "\u2026")))))));
}

// ─── TYPOGRAPHY TAB ───────────────────────────────────────
function TypographyTab() {
  const scale = [{
    size: "5xl",
    label: "Hero",
    weight: "extrabold",
    sample: "Somos el puente entre la comunicación"
  }, {
    size: "4xl",
    label: "H1 Página",
    weight: "bold",
    sample: "Automatiza tu atención al cliente"
  }, {
    size: "3xl",
    label: "H2 Sección",
    weight: "bold",
    sample: "¿Quiénes somos?"
  }, {
    size: "2xl",
    label: "H3",
    weight: "semibold",
    sample: "Servicios de comunicación masiva"
  }, {
    size: "xl",
    label: "H4",
    weight: "semibold",
    sample: "WhatsApp API Business"
  }, {
    size: "lg",
    label: "Body Large",
    weight: "regular",
    sample: "Celcom es un integrador móvil de valor agregado que ofrece plataformas bidireccionales de contactabilidad."
  }, {
    size: "base",
    label: "Body Base",
    weight: "regular",
    sample: "Conecta con tus clientes a través de la app de mensajería más utilizada en el mundo."
  }, {
    size: "sm",
    label: "Caption",
    weight: "medium",
    sample: "Términos y condiciones · Política de privacidad · SUBTEL"
  }, {
    size: "xs",
    label: "Label/Overline",
    weight: "semibold",
    sample: "SERVICIO CHATBOT · SMS MASIVO · WHATSAPP API"
  }];
  return /*#__PURE__*/React.createElement(Section, {
    title: "Escala Tipogr\xE1fica",
    subtitle: "Poppins para t\xEDtulos \xB7 Inter para cuerpo \xB7 escala 1.25x"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 0,
      borderRadius: T.radii.xl,
      overflow: "hidden",
      border: `1px solid ${C.neutral[200]}`
    }
  }, scale.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: item.size,
    style: {
      padding: "18px 24px",
      background: i % 2 === 0 ? C.neutral.white : C.neutral[50],
      display: "flex",
      alignItems: "baseline",
      gap: 24,
      borderBottom: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 130,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    color: C.brand.primary
  }, item.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: C.neutral[400],
      marginTop: 4,
      marginBottom: 0
    }
  }, T.typography.scale[item.size], " \xB7 ", item.weight)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: T.typography.families.heading,
      fontSize: T.typography.scale[item.size],
      fontWeight: T.typography.weights[item.weight],
      color: C.neutral[900],
      lineHeight: T.typography.lineHeights.tight,
      margin: 0,
      maxWidth: 580
    }
  }, item.sample)))));
}

// ─── BASE COMPONENTS TAB ──────────────────────────────────
function InputField({
  label,
  placeholder,
  hint,
  error,
  type = "text"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: T.typography.scale.sm,
      fontWeight: T.typography.weights.semibold,
      color: C.neutral[700]
    }
  }, label), /*#__PURE__*/React.createElement("input", {
    type: type,
    placeholder: placeholder,
    readOnly: true,
    style: {
      padding: "10px 14px",
      borderRadius: T.radii.md,
      border: `1.5px solid ${error ? C.semantic.error : C.neutral[300]}`,
      fontSize: T.typography.scale.base,
      fontFamily: T.typography.families.body,
      color: C.neutral[900],
      outline: "none",
      background: C.neutral.white
    }
  }), hint && !error && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[400],
      margin: 0
    }
  }, hint), error && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.semantic.error,
      margin: 0
    }
  }, "\u26A0 ", error));
}
function AlertBox({
  type,
  title,
  message
}) {
  const map = {
    success: {
      bg: "#ECFDF5",
      border: C.semantic.success,
      icon: "✓"
    },
    warning: {
      bg: "#FFFBEB",
      border: C.semantic.warning,
      icon: "⚠"
    },
    error: {
      bg: "#FEF2F2",
      border: C.semantic.error,
      icon: "✕"
    },
    info: {
      bg: "#EFF6FF",
      border: C.semantic.info,
      icon: "ℹ"
    },
    accent: {
      bg: "#FFFBEB",
      border: C.brand.accent,
      icon: "★"
    }
  };
  const m = map[type];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: m.bg,
      border: `1px solid ${m.border}`,
      borderLeft: `4px solid ${m.border}`,
      borderRadius: T.radii.md,
      padding: "12px 16px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      color: m.border,
      fontSize: T.typography.scale.sm,
      margin: "0 0 2px"
    }
  }, m.icon, " ", title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[700],
      margin: 0
    }
  }, message));
}
function ComponentsTab() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    title: "Botones",
    subtitle: "Sistema de botones con acento amarillo como variante secundaria de alto impacto."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Label, null, "Variantes"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "primary"
  }, "Quiero usarla"), /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    icon: "\u2605"
  }, "Comenzar gratis"), /*#__PURE__*/React.createElement(Btn, {
    variant: "secondary"
  }, "Ver servicios"), /*#__PURE__*/React.createElement(Btn, {
    variant: "ghost"
  }, "Cancelar"), /*#__PURE__*/React.createElement(Btn, {
    variant: "dark"
  }, "Plataforma"), /*#__PURE__*/React.createElement(Btn, {
    variant: "danger"
  }, "Eliminar")), /*#__PURE__*/React.createElement(Label, null, "Tama\xF1os"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      alignItems: "center",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    size: "xs",
    variant: "accent"
  }, "XS"), /*#__PURE__*/React.createElement(Btn, {
    size: "sm",
    variant: "accent"
  }, "Peque\xF1o"), /*#__PURE__*/React.createElement(Btn, {
    size: "md",
    variant: "accent"
  }, "Mediano"), /*#__PURE__*/React.createElement(Btn, {
    size: "lg",
    variant: "accent"
  }, "Grande")), /*#__PURE__*/React.createElement(Label, null, "Estados y uso del acento"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.brand.secondary,
      padding: 20,
      borderRadius: T.radii.lg,
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    icon: "\uD83D\uDE80"
  }, "Comenzar ahora"), /*#__PURE__*/React.createElement(Btn, {
    variant: "secondary",
    size: "sm"
  }, "Ver demo"), /*#__PURE__*/React.createElement(Btn, {
    disabled: true,
    size: "md"
  }, "Deshabilitado")))), /*#__PURE__*/React.createElement(Section, {
    title: "Formularios",
    subtitle: "Campos con validaci\xF3n, usados en cotizaci\xF3n y contacto."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Grid, {
    cols: 2,
    gap: 20
  }, /*#__PURE__*/React.createElement(InputField, {
    label: "Nombre",
    placeholder: "Juan P\xE9rez",
    hint: "Nombre completo"
  }), /*#__PURE__*/React.createElement(InputField, {
    label: "Correo corporativo",
    placeholder: "juan@empresa.com",
    type: "email"
  }), /*#__PURE__*/React.createElement(InputField, {
    label: "Empresa",
    placeholder: "Nombre de tu empresa"
  }), /*#__PURE__*/React.createElement(InputField, {
    label: "Tel\xE9fono",
    placeholder: "+56 9 1234 5678",
    error: "N\xFAmero inv\xE1lido"
  })))), /*#__PURE__*/React.createElement(Section, {
    title: "Alertas & Notificaciones",
    subtitle: "Feedback del sistema. El acento amarillo para avisos promocionales."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(AlertBox, {
    type: "accent",
    title: "\xA1Nuevo! Celcom Flex disponible",
    message: "Tu plan ahora incluye acceso a la plataforma omnicanal. Act\xEDvala sin costo adicional."
  }), /*#__PURE__*/React.createElement(AlertBox, {
    type: "success",
    title: "Formulario enviado",
    message: "Nuestro equipo se comunicar\xE1 contigo en menos de 24 horas."
  }), /*#__PURE__*/React.createElement(AlertBox, {
    type: "info",
    title: "Verificaci\xF3n en proceso",
    message: "Tu n\xFAmero de WhatsApp est\xE1 siendo validado. Toma entre 7\u201320 d\xEDas h\xE1biles."
  }), /*#__PURE__*/React.createElement(AlertBox, {
    type: "warning",
    title: "Saldo bajo",
    message: "Tu cuenta tiene menos de 500 cr\xE9ditos SMS. Recarga para mantener tus env\xEDos activos."
  }), /*#__PURE__*/React.createElement(AlertBox, {
    type: "error",
    title: "Error de autenticaci\xF3n",
    message: "Las credenciales no son v\xE1lidas. Revisa tu service_id y clave."
  }))), /*#__PURE__*/React.createElement(Section, {
    title: "Chips & Badges",
    subtitle: "Estado, categor\xEDa y acento para destacar planes o features."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    color: C.brand.accent,
    bg: C.brand.accent + "22"
  }, "\u2605 Destacado"), /*#__PURE__*/React.createElement(Chip, {
    color: C.brand.accent,
    bg: C.brand.accent + "22"
  }, "Pro"), /*#__PURE__*/React.createElement(Chip, {
    color: C.channels.whatsapp
  }, "WhatsApp"), /*#__PURE__*/React.createElement(Chip, {
    color: C.channels.sms
  }, "SMS"), /*#__PURE__*/React.createElement(Chip, {
    color: C.channels.email,
    bg: C.brand.accent + "22"
  }, "Email"), /*#__PURE__*/React.createElement(Chip, {
    color: C.channels.chatbot
  }, "Chatbot"), /*#__PURE__*/React.createElement(Chip, {
    color: C.semantic.success
  }, "Activo"), /*#__PURE__*/React.createElement(Chip, {
    color: C.semantic.warning,
    bg: C.semantic.warning + "22"
  }, "Pendiente"), /*#__PURE__*/React.createElement(Chip, {
    color: C.semantic.error
  }, "Suspendido"), /*#__PURE__*/React.createElement(Chip, {
    color: C.brand.primaryLight
  }, "Beta"), /*#__PURE__*/React.createElement(Chip, {
    color: C.neutral[500]
  }, "Archivado")))));
}

// ─── SAAS COMPONENTS TAB ──────────────────────────────────
function ProgressBar({
  value,
  color = C.brand.primary,
  label,
  showValue = true
}) {
  return /*#__PURE__*/React.createElement("div", null, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 6
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[700],
      fontWeight: 500
    }
  }, label), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[500]
    }
  }, value, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral[200],
      borderRadius: T.radii.full,
      height: 8,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${value}%`,
      height: "100%",
      background: color,
      borderRadius: T.radii.full,
      transition: T.motion.slow
    }
  })));
}
function StatusDot({
  status
}) {
  const map = {
    online: {
      color: C.semantic.success,
      label: "Online"
    },
    degraded: {
      color: C.brand.accent,
      label: "Degradado"
    },
    offline: {
      color: C.semantic.error,
      label: "Offline"
    },
    idle: {
      color: C.neutral[400],
      label: "Inactivo"
    }
  };
  const m = map[status];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontSize: T.typography.scale.xs,
      color: m.color,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: m.color,
      boxShadow: `0 0 0 2px ${m.color}44`,
      display: "inline-block"
    }
  }), m.label);
}
function KpiCard({
  icon,
  label,
  value,
  delta,
  deltaType = "up",
  color = C.brand.primary
}) {
  const isUp = deltaType === "up";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral.white,
      borderRadius: T.radii.xl,
      padding: "20px 22px",
      boxShadow: T.shadows.sm,
      border: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      background: color + "18",
      borderRadius: T.radii.md,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 20
    }
  }, icon), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.xs,
      fontWeight: 700,
      color: isUp ? C.semantic.success : C.semantic.error,
      background: (isUp ? C.semantic.success : C.semantic.error) + "15",
      padding: "2px 8px",
      borderRadius: T.radii.full
    }
  }, isUp ? "▲" : "▼", " ", delta)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale["2xl"],
      fontWeight: T.typography.weights.extrabold,
      color: C.neutral[900],
      margin: "0 0 2px",
      fontFamily: T.typography.families.heading
    }
  }, value), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[500],
      margin: 0
    }
  }, label));
}
function PricingCard({
  plan,
  price,
  period = "/mes",
  description,
  features,
  cta,
  highlighted,
  badge
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: highlighted ? C.brand.secondary : C.neutral.white,
      borderRadius: T.radii["2xl"],
      padding: "28px 24px",
      border: highlighted ? "none" : `1px solid ${C.neutral[200]}`,
      boxShadow: highlighted ? T.shadows.xl : T.shadows.sm,
      position: "relative",
      display: "flex",
      flexDirection: "column"
    }
  }, badge && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -12,
      left: "50%",
      transform: "translateX(-50%)",
      background: C.brand.accent,
      color: C.brand.secondary,
      fontSize: T.typography.scale.xs,
      fontWeight: 800,
      padding: "4px 16px",
      borderRadius: T.radii.full,
      boxShadow: T.shadows.accent,
      whiteSpace: "nowrap"
    }
  }, badge), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: T.typography.weights.bold,
      fontSize: T.typography.scale.base,
      color: highlighted ? C.brand.accent : C.brand.primary,
      margin: "0 0 4px",
      textTransform: "uppercase",
      letterSpacing: "0.06em"
    }
  }, plan), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: highlighted ? "rgba(255,255,255,0.55)" : C.neutral[500],
      margin: "0 0 16px"
    }
  }, description), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 4,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: T.typography.families.heading,
      fontSize: T.typography.scale["4xl"],
      fontWeight: 800,
      color: highlighted ? "#fff" : C.neutral[900]
    }
  }, price), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      color: highlighted ? "rgba(255,255,255,0.5)" : C.neutral[400]
    }
  }, period)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      marginBottom: 24
    }
  }, features.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: f.inc ? highlighted ? C.brand.accent : C.semantic.success : C.neutral[300],
      fontSize: 14,
      flexShrink: 0
    }
  }, f.inc ? "✓" : "✕"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      color: highlighted ? f.inc ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.3)" : f.inc ? C.neutral[700] : C.neutral[300]
    }
  }, f.label)))), /*#__PURE__*/React.createElement(Btn, {
    variant: highlighted ? "accent" : "secondary",
    fullWidth: true
  }, cta));
}
function StepperFlow({
  steps,
  current = 1
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 0
    }
  }, steps.map((step, i) => {
    const done = i < current;
    const active = i === current;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        width: "100%",
        alignItems: "center"
      }
    }, i > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 2,
        background: done ? C.brand.accent : C.neutral[200]
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 36,
        borderRadius: "50%",
        flexShrink: 0,
        background: done ? C.brand.accent : active ? C.brand.primary : C.neutral[200],
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 14,
        fontWeight: 700,
        color: done ? C.brand.secondary : active ? "#fff" : C.neutral[400],
        boxShadow: active ? T.shadows.md : "none",
        border: active ? `3px solid ${C.brand.primaryLight}` : "none",
        zIndex: 1
      }
    }, done ? "✓" : i + 1), i < steps.length - 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 2,
        background: done ? C.brand.accent : C.neutral[200]
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "center",
        marginTop: 8,
        padding: "0 4px"
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: T.typography.scale.xs,
        fontWeight: active ? 700 : 500,
        color: active ? C.brand.primary : done ? C.neutral[700] : C.neutral[400],
        margin: "0 0 2px"
      }
    }, step.label), step.sub && /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 9,
        color: C.neutral[400],
        margin: 0
      }
    }, step.sub)));
  }));
}
function Toast({
  type = "info",
  title,
  message,
  onClose
}) {
  const map = {
    success: {
      icon: "✓",
      color: C.semantic.success
    },
    warning: {
      icon: "⚠",
      color: C.brand.accent
    },
    error: {
      icon: "✕",
      color: C.semantic.error
    },
    info: {
      icon: "ℹ",
      color: C.semantic.info
    }
  };
  const m = map[type];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral.white,
      borderRadius: T.radii.lg,
      boxShadow: T.shadows.xl,
      border: `1px solid ${C.neutral[200]}`,
      borderLeft: `4px solid ${m.color}`,
      padding: "14px 16px",
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      width: 320
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      background: m.color + "18",
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: m.color,
      fontSize: 13,
      fontWeight: 800,
      flexShrink: 0
    }
  }, m.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: T.typography.scale.sm,
      color: C.neutral[900],
      margin: "0 0 2px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[500],
      margin: 0
    }
  }, message)), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: C.neutral[400],
      fontSize: 16,
      padding: 0,
      lineHeight: 1
    }
  }, "\xD7"));
}
function UsageMeter({
  label,
  used,
  total,
  unit,
  color = C.brand.primary,
  warn = 80
}) {
  const pct = Math.round(used / total * 100);
  const barColor = pct >= warn ? C.semantic.error : pct >= warn * 0.8 ? C.brand.accent : color;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral.white,
      borderRadius: T.radii.lg,
      padding: "16px 18px",
      border: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      fontWeight: 600,
      color: C.neutral[700]
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[500]
    }
  }, used.toLocaleString(), " / ", total.toLocaleString(), " ", unit)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.neutral[200],
      borderRadius: T.radii.full,
      height: 6,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: "100%",
      background: barColor,
      borderRadius: T.radii.full
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      color: pct >= warn ? C.semantic.error : C.neutral[400],
      fontWeight: pct >= warn ? 700 : 400
    }
  }, pct, "% utilizado", pct >= warn ? " — recarga pronto" : "")));
}
function EmptyState({
  icon,
  title,
  message,
  ctaLabel,
  ctaVariant = "accent"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "48px 24px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      height: 72,
      background: C.neutral[100],
      borderRadius: T.radii["2xl"],
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 32
    }
  }, icon), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: T.typography.families.heading,
      fontWeight: 700,
      fontSize: T.typography.scale.lg,
      color: C.neutral[900],
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[500],
      maxWidth: 280,
      lineHeight: 1.6,
      margin: 0
    }
  }, message), ctaLabel && /*#__PURE__*/React.createElement(Btn, {
    variant: ctaVariant,
    size: "sm",
    icon: "+"
  }, ctaLabel));
}
function ApiKeyRow({
  label,
  keyValue
}) {
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);
  const masked = "••••••••••••" + keyValue.slice(-6);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      background: C.neutral[50],
      borderRadius: T.radii.md,
      padding: "10px 14px",
      border: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: C.neutral[500],
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.06em",
      margin: "0 0 2px"
    }
  }, label), /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: T.typography.families.mono,
      fontSize: T.typography.scale.sm,
      color: C.neutral[900]
    }
  }, visible ? keyValue : masked)), /*#__PURE__*/React.createElement("button", {
    onClick: () => setVisible(!visible),
    style: {
      background: "none",
      border: `1px solid ${C.neutral[300]}`,
      borderRadius: T.radii.sm,
      padding: "4px 10px",
      cursor: "pointer",
      fontSize: T.typography.scale.xs,
      color: C.neutral[500]
    }
  }, visible ? "Ocultar" : "Ver"), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      navigator.clipboard?.writeText(keyValue);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    },
    style: {
      background: copied ? C.semantic.success + "18" : C.brand.accent + "18",
      border: `1px solid ${copied ? C.semantic.success : C.brand.accent}`,
      borderRadius: T.radii.sm,
      padding: "4px 10px",
      cursor: "pointer",
      fontSize: T.typography.scale.xs,
      color: copied ? C.semantic.success : C.brand.accentDark,
      fontWeight: 600
    }
  }, copied ? "✓ Copiado" : "Copiar"));
}
function SidebarNav({
  activeItem,
  onSelect
}) {
  const groups = [{
    label: "Principal",
    items: [{
      icon: "📊",
      label: "Dashboard",
      id: "dashboard"
    }, {
      icon: "📱",
      label: "Campañas",
      id: "campaigns"
    }, {
      icon: "💬",
      label: "WhatsApp",
      id: "whatsapp",
      badge: "3"
    }, {
      icon: "✉️",
      label: "Email",
      id: "email"
    }, {
      icon: "🤖",
      label: "Chatbots",
      id: "chatbots"
    }]
  }, {
    label: "Configuración",
    items: [{
      icon: "🔑",
      label: "API Keys",
      id: "api"
    }, {
      icon: "⚙️",
      label: "Ajustes",
      id: "settings"
    }, {
      icon: "💳",
      label: "Facturación",
      id: "billing",
      badge: "!",
      badgeColor: C.brand.accent
    }]
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200,
      background: C.brand.secondary,
      borderRadius: T.radii.xl,
      padding: "16px 12px",
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 12px",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.brand.accent,
      fontWeight: 800,
      fontSize: T.typography.scale.base,
      fontFamily: T.typography.families.heading,
      margin: 0
    }
  }, "celcom"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.4)",
      fontSize: T.typography.scale.xs,
      margin: 0
    }
  }, "Plataforma")), groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.label,
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.35)",
      fontSize: 9,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      padding: "0 12px",
      margin: "0 0 4px"
    }
  }, g.label), g.items.map(item => {
    const active = activeItem === item.id;
    return /*#__PURE__*/React.createElement("button", {
      key: item.id,
      onClick: () => onSelect(item.id),
      style: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 12px",
        background: active ? C.brand.accent + "22" : "transparent",
        border: "none",
        borderRadius: T.radii.md,
        cursor: "pointer",
        textAlign: "left"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15
      }
    }, item.icon), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontSize: T.typography.scale.sm,
        fontWeight: active ? 700 : 500,
        color: active ? C.brand.accent : "rgba(255,255,255,0.7)"
      }
    }, item.label), item.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        background: item.badgeColor || C.brand.primaryLight,
        color: item.badgeColor === C.brand.accent ? C.brand.secondary : "#fff",
        fontSize: 9,
        fontWeight: 800,
        padding: "1px 6px",
        borderRadius: T.radii.full
      }
    }, item.badge));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      borderTop: "1px solid rgba(255,255,255,0.1)",
      paddingTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "8px 12px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      background: C.brand.accent,
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      fontWeight: 800,
      color: C.brand.secondary
    }
  }, "M"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.85)",
      fontSize: T.typography.scale.xs,
      fontWeight: 600,
      margin: 0
    }
  }, "Miguel SM"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.35)",
      fontSize: 9,
      margin: 0
    }
  }, "Admin")))));
}
function SaaSTab() {
  const [currentStep] = useState(2);
  const [sidebarActive, setSidebarActive] = useState("dashboard");
  const plans = [{
    plan: "Starter",
    price: "$49",
    description: "Para empresas que inician",
    features: [{
      label: "5.000 SMS/mes",
      inc: true
    }, {
      label: "WhatsApp API",
      inc: false
    }, {
      label: "Email Marketing",
      inc: true
    }, {
      label: "1 Chatbot",
      inc: false
    }, {
      label: "Soporte básico",
      inc: true
    }],
    cta: "Comenzar gratis"
  }, {
    plan: "Pro",
    price: "$149",
    description: "El más popular para crecer",
    badge: "★ Más popular",
    features: [{
      label: "50.000 SMS/mes",
      inc: true
    }, {
      label: "WhatsApp API",
      inc: true
    }, {
      label: "Email Marketing",
      inc: true
    }, {
      label: "3 Chatbots",
      inc: true
    }, {
      label: "Soporte prioritario",
      inc: true
    }],
    cta: "Activar plan Pro",
    highlighted: true
  }, {
    plan: "Enterprise",
    price: "Custom",
    period: "",
    description: "Para grandes volúmenes",
    features: [{
      label: "SMS ilimitados",
      inc: true
    }, {
      label: "WhatsApp API",
      inc: true
    }, {
      label: "Email Marketing",
      inc: true
    }, {
      label: "Chatbots ilimitados",
      inc: true
    }, {
      label: "SLA + soporte dedicado",
      inc: true
    }],
    cta: "Hablar con ventas"
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    title: "KPI Dashboard Cards",
    subtitle: "M\xE9tricas clave para el panel de control SaaS de Celcom."
  }, /*#__PURE__*/React.createElement(Grid, {
    cols: 4,
    gap: 16
  }, /*#__PURE__*/React.createElement(KpiCard, {
    icon: "\uD83D\uDCF1",
    label: "SMS enviados este mes",
    value: "47.320",
    delta: "12%",
    deltaType: "up",
    color: C.channels.sms
  }), /*#__PURE__*/React.createElement(KpiCard, {
    icon: "\uD83D\uDCAC",
    label: "Conversaciones WhatsApp",
    value: "8.941",
    delta: "8%",
    deltaType: "up",
    color: C.channels.whatsapp
  }), /*#__PURE__*/React.createElement(KpiCard, {
    icon: "\u2709\uFE0F",
    label: "Emails entregados",
    value: "23.100",
    delta: "3%",
    deltaType: "down",
    color: C.brand.accent
  }), /*#__PURE__*/React.createElement(KpiCard, {
    icon: "\uD83E\uDD16",
    label: "Interacciones chatbot",
    value: "11.500",
    delta: "21%",
    deltaType: "up",
    color: C.channels.chatbot
  }))), /*#__PURE__*/React.createElement(Section, {
    title: "Pricing Cards",
    subtitle: "Tarjetas de planes. El plan destacado usa el acento amarillo como elemento de confianza."
  }, /*#__PURE__*/React.createElement(Grid, {
    cols: 3,
    gap: 20
  }, plans.map(p => /*#__PURE__*/React.createElement(PricingCard, _extends({
    key: p.plan
  }, p))))), /*#__PURE__*/React.createElement(Section, {
    title: "Onboarding Stepper",
    subtitle: "Flujo guiado de activaci\xF3n de servicio (paso actual: 3 de 5)."
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: "28px 32px"
    }
  }, /*#__PURE__*/React.createElement(StepperFlow, {
    current: currentStep,
    steps: [{
      label: "Crea tu cuenta",
      sub: "Datos básicos"
    }, {
      label: "Elige un plan",
      sub: "Starter / Pro"
    }, {
      label: "Conecta canal",
      sub: "WhatsApp / SMS"
    }, {
      label: "Configura bot",
      sub: "Árbol de respuestas"
    }, {
      label: "¡Listo!",
      sub: "Primer envío"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      padding: "20px 24px",
      background: C.neutral[50],
      borderRadius: T.radii.lg,
      border: `1px solid ${C.neutral[200]}`
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      color: C.neutral[900],
      fontSize: T.typography.scale.base,
      margin: "0 0 6px"
    }
  }, "Paso 3 \u2014 Conecta tu canal de WhatsApp"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[500],
      margin: "0 0 16px"
    }
  }, "Ingresa el n\xFAmero de WhatsApp Business que deseas activar. La verificaci\xF3n toma entre 7\u201320 d\xEDas h\xE1biles."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    size: "sm",
    icon: "\u2192"
  }, "Continuar"), /*#__PURE__*/React.createElement(Btn, {
    variant: "ghost",
    size: "sm"
  }, "Atr\xE1s"))))), /*#__PURE__*/React.createElement(Section, {
    title: "Usage Meters",
    subtitle: "Indicadores de consumo de cr\xE9ditos y recursos del plan activo."
  }, /*#__PURE__*/React.createElement(Grid, {
    cols: 2,
    gap: 16
  }, /*#__PURE__*/React.createElement(UsageMeter, {
    label: "SMS Masivo",
    used: 43200,
    total: 50000,
    unit: "mensajes",
    color: C.channels.sms,
    warn: 85
  }), /*#__PURE__*/React.createElement(UsageMeter, {
    label: "WhatsApp API",
    used: 6800,
    total: 10000,
    unit: "conversaciones",
    color: C.channels.whatsapp,
    warn: 80
  }), /*#__PURE__*/React.createElement(UsageMeter, {
    label: "Email Marketing",
    used: 12000,
    total: 50000,
    unit: "env\xEDos",
    color: C.brand.accent,
    warn: 80
  }), /*#__PURE__*/React.createElement(UsageMeter, {
    label: "Almacenamiento",
    used: 2300,
    total: 5000,
    unit: "MB",
    color: C.channels.chatbot,
    warn: 80
  }))), /*#__PURE__*/React.createElement(Section, {
    title: "Toast Notifications",
    subtitle: "Feedback contextual flotante del sistema."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    type: "success",
    title: "Campa\xF1a enviada",
    message: "47.320 SMS entregados correctamente."
  }), /*#__PURE__*/React.createElement(Toast, {
    type: "warning",
    title: "Cr\xE9ditos bajos",
    message: "Te quedan 720 SMS en tu plan actual."
  }), /*#__PURE__*/React.createElement(Toast, {
    type: "error",
    title: "Fallo en env\xEDo",
    message: "45 n\xFAmeros no pudieron recibir el mensaje."
  }), /*#__PURE__*/React.createElement(Toast, {
    type: "info",
    title: "Actualizaci\xF3n",
    message: "El sistema estar\xE1 en mantenimiento el 20/04."
  }))), /*#__PURE__*/React.createElement(Section, {
    title: "Status Indicators",
    subtitle: "Estado de los canales y la plataforma en tiempo real."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 0
    }
  }, [{
    channel: "SMS Gateway",
    status: "online"
  }, {
    channel: "WhatsApp API",
    status: "online"
  }, {
    channel: "Email Server",
    status: "degraded"
  }, {
    channel: "Chatbot Engine",
    status: "online"
  }, {
    channel: "Panel de Control",
    status: "online"
  }, {
    channel: "API Pública",
    status: "offline"
  }].map((row, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "12px 16px",
      background: i % 2 === 0 ? C.neutral[50] : C.neutral.white,
      borderBottom: i < 5 ? `1px solid ${C.neutral[200]}` : "none",
      borderRadius: i === 0 ? `${T.radii.md} ${T.radii.md} 0 0` : i === 5 ? `0 0 ${T.radii.md} ${T.radii.md}` : "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[700],
      fontWeight: 500
    }
  }, row.channel), /*#__PURE__*/React.createElement(StatusDot, {
    status: row.status
  })))))), /*#__PURE__*/React.createElement(Section, {
    title: "API Key Manager",
    subtitle: "Gesti\xF3n de credenciales de integraci\xF3n para la API de Celcom."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(ApiKeyRow, {
    label: "Production API Key",
    keyValue: "sk_live_celcom_a1b2c3d4e5f6789012345678"
  }), /*#__PURE__*/React.createElement(ApiKeyRow, {
    label: "Sandbox API Key",
    keyValue: "sk_test_celcom_z9y8x7w6v5u4321098765432"
  }), /*#__PURE__*/React.createElement(ApiKeyRow, {
    label: "Webhook Secret",
    keyValue: "whsec_celcom_m5n4o3p2q1r0987654321abc"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    size: "sm",
    icon: "\u2295"
  }, "Generar nueva clave")))), /*#__PURE__*/React.createElement(Section, {
    title: "Empty States",
    subtitle: "Estados vac\xEDos para secciones sin datos a\xFAn."
  }, /*#__PURE__*/React.createElement(Grid, {
    cols: 3,
    gap: 16
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "\uD83D\uDCF1",
    title: "Sin campa\xF1as a\xFAn",
    message: "Crea tu primera campa\xF1a de SMS masivo y llega a tus clientes.",
    ctaLabel: "Nueva campa\xF1a"
  })), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "\uD83D\uDCAC",
    title: "Conecta WhatsApp",
    message: "A\xFAn no tienes un n\xFAmero de WhatsApp Business activado.",
    ctaLabel: "Activar canal"
  })), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "\uD83D\uDCCA",
    title: "Sin datos a\xFAn",
    message: "Aqu\xED aparecer\xE1n las m\xE9tricas cuando env\xEDes tu primera campa\xF1a.",
    ctaLabel: null
  })))), /*#__PURE__*/React.createElement(Section, {
    title: "Sidebar Navigation",
    subtitle: "Men\xFA lateral del panel de control con acceso a m\xF3dulos y cuenta."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SidebarNav, {
    activeItem: sidebarActive,
    onSelect: setSidebarActive
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: C.neutral[100],
      borderRadius: T.radii.xl,
      border: `1px dashed ${C.neutral[300]}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 320
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.neutral[400],
      fontSize: T.typography.scale.sm
    }
  }, "Contenido del m\xF3dulo: ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: C.brand.primary
    }
  }, sidebarActive))))), /*#__PURE__*/React.createElement(Section, {
    title: "Trial & Upgrade Banners",
    subtitle: "Banners de contexto para promover el upgrade usando el acento amarillo."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: `linear-gradient(135deg,${C.brand.accent} 0%,${C.brand.accentLight} 100%)`,
      borderRadius: T.radii.xl,
      padding: "18px 24px",
      display: "flex",
      alignItems: "center",
      gap: 16,
      boxShadow: T.shadows.accent
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, "\u23F3"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 800,
      color: C.brand.secondary,
      fontSize: T.typography.scale.base,
      margin: "0 0 2px"
    }
  }, "Tu prueba gratuita vence en 5 d\xEDas"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.brand.secondary,
      opacity: 0.65,
      margin: 0
    }
  }, "Actualiza ahora y mant\xE9n todos tus flujos de comunicaci\xF3n activos.")), /*#__PURE__*/React.createElement(Btn, {
    variant: "dark",
    size: "sm"
  }, "Actualizar plan \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.brand.secondary,
      borderRadius: T.radii.xl,
      padding: "16px 24px",
      display: "flex",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24
    }
  }, "\uD83D\uDE80"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      color: "#fff",
      fontSize: T.typography.scale.sm,
      margin: "0 0 2px"
    }
  }, "Desbloquea WhatsApp API en tu plan"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: "rgba(255,255,255,0.5)",
      margin: 0
    }
  }, "Con el plan Pro obtienes conversaciones ilimitadas y soporte prioritario.")), /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    size: "sm"
  }, "Ver Plan Pro")))));
}

// ─── PATTERNS TAB ─────────────────────────────────────────
function PatternsTab() {
  const [activeTab, setActiveTab] = useState("WhatsApp API");
  const [openFaq, setOpenFaq] = useState(null);
  const faqs = [{
    q: "¿Qué es un chatbot?",
    a: "Un chatbot es un programa informático que automatiza servicios de chat. Envía respuestas rápidas, recibe mensajes y transfiere conversaciones en tiempo real."
  }, {
    q: "¿Qué canales puedo conectar?",
    a: "Nuestra plataforma puede conectarse con múltiples canales de forma directa o a través del API."
  }, {
    q: "¿El chatbot puede ser híbrido?",
    a: "Sí, la operación puede ser 100% personas, 100% bots o híbrida (bot + agente humano)."
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    title: "Hero Section",
    subtitle: "Portada principal con headline, subt\xEDtulo y CTA doble (primario + acento)."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: T.radii.xl,
      overflow: "hidden",
      boxShadow: T.shadows.xl
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: `linear-gradient(135deg,${C.brand.primaryDark} 0%,${C.brand.primary} 70%)`,
      padding: "52px 48px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 500
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.brand.accent,
      fontWeight: 700,
      fontSize: T.typography.scale.sm,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      margin: "0 0 12px"
    }
  }, "Celcom Latam"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: T.typography.families.heading,
      fontSize: "clamp(1.4rem,2.5vw,2.25rem)",
      fontWeight: 800,
      color: "#fff",
      lineHeight: 1.2,
      margin: "0 0 14px"
    }
  }, "Somos el puente entre la comunicaci\xF3n que deseas y las herramientas para lograrlo"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.65)",
      fontSize: T.typography.scale.base,
      margin: "0 0 28px",
      lineHeight: 1.6
    }
  }, "SMS, WhatsApp API, Email Marketing y Chatbots para empresas."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "accent",
    size: "lg",
    icon: "\u2605"
  }, "Comenzar gratis"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "transparent",
      color: "rgba(255,255,255,0.8)",
      border: "2px solid rgba(255,255,255,0.3)",
      padding: "13px 24px",
      borderRadius: T.radii.md,
      fontWeight: 600,
      fontSize: T.typography.scale.base,
      cursor: "pointer"
    }
  }, "Ver demo"))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200,
      height: 150,
      background: "rgba(255,255,255,0.08)",
      borderRadius: T.radii.xl,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 56,
      flexShrink: 0
    }
  }, "\uD83D\uDCE1")))), /*#__PURE__*/React.createElement(Section, {
    title: "Tabs de Servicios",
    subtitle: "Navegaci\xF3n tabular para selecci\xF3n de canal o servicio."
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      borderBottom: `2px solid ${C.neutral[200]}`,
      marginBottom: 20
    }
  }, ["WhatsApp API", "SMS Masivo", "Email Marketing", "Chatbot"].map(t => {
    const active = activeTab === t;
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      onClick: () => setActiveTab(t),
      style: {
        padding: "10px 18px",
        border: "none",
        background: "transparent",
        fontWeight: active ? 700 : 500,
        cursor: "pointer",
        color: active ? C.brand.primary : C.neutral[500],
        borderBottom: active ? `3px solid ${C.brand.accent}` : "3px solid transparent",
        fontSize: T.typography.scale.sm,
        fontFamily: T.typography.families.body,
        marginBottom: -2
      }
    }, t);
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.neutral[700],
      fontSize: T.typography.scale.sm,
      margin: 0
    }
  }, activeTab === "WhatsApp API" && "Conecta con tus clientes a través de la app de mensajería más utilizada del mundo con las ventajas de la versión Business.", activeTab === "SMS Masivo" && "Llega a donde tu cliente esté a través de mensajería instantánea y potencia tus campañas de marketing.", activeTab === "Email Marketing" && "Potencia tus campañas y mantén a tu cliente al día con los lanzamientos de tu marca.", activeTab === "Chatbot" && "Disponible 24/7 para tus prospectos. Evita perder ventas con bots en tu tono de comunicación."))), /*#__PURE__*/React.createElement(Section, {
    title: "FAQ Accordion",
    subtitle: "Preguntas frecuentes en p\xE1ginas de servicio."
  }, /*#__PURE__*/React.createElement(Card, null, faqs.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderBottom: i < faqs.length - 1 ? `1px solid ${C.neutral[200]}` : "none"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpenFaq(openFaq === i ? null : i),
    style: {
      width: "100%",
      textAlign: "left",
      padding: "16px 0",
      background: "transparent",
      border: "none",
      cursor: "pointer",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontWeight: T.typography.weights.semibold,
      fontSize: T.typography.scale.base,
      color: C.neutral[900],
      fontFamily: T.typography.families.body
    }
  }, f.q, /*#__PURE__*/React.createElement("span", {
    style: {
      color: C.brand.accent,
      fontSize: 20,
      transform: openFaq === i ? "rotate(45deg)" : "none",
      transition: T.motion.fast,
      display: "inline-block",
      lineHeight: 1
    }
  }, "+")), openFaq === i && /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.neutral[500],
      fontSize: T.typography.scale.sm,
      lineHeight: 1.7,
      paddingBottom: 16,
      margin: 0
    }
  }, f.a))))), /*#__PURE__*/React.createElement(Section, {
    title: "Footer",
    subtitle: "Pie de p\xE1gina completo con navegaci\xF3n, pa\xEDses y contacto."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.brand.secondary,
      borderRadius: T.radii.xl,
      padding: "36px 36px 20px",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr 1fr",
      gap: 36,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: C.brand.accent,
      fontWeight: 800,
      fontSize: T.typography.scale.lg,
      fontFamily: T.typography.families.heading,
      margin: "0 0 8px"
    }
  }, "celcom"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: "rgba(255,255,255,0.5)",
      lineHeight: 1.6,
      margin: "0 0 16px"
    }
  }, "General Holley 133, Providencia, Santiago, Chile."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, ["🇨🇱", "🇵🇪", "🇲🇽", "🇨🇴", "🇧🇴"].map((f, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 20
    }
  }, f)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: T.typography.scale.xs,
      color: C.brand.accent,
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      margin: "0 0 12px"
    }
  }, "Servicios"), ["SMS Marketing", "WhatsApp API", "Email Marketing", "Chatbot"].map(s => /*#__PURE__*/React.createElement("p", {
    key: s,
    style: {
      fontSize: T.typography.scale.sm,
      color: "rgba(255,255,255,0.55)",
      margin: "0 0 8px"
    }
  }, s))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: T.typography.scale.xs,
      color: C.brand.accent,
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      margin: "0 0 12px"
    }
  }, "Contacto"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: "rgba(255,255,255,0.55)",
      margin: "0 0 8px"
    }
  }, "contacto@celcom.cl"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: "rgba(255,255,255,0.55)",
      margin: 0
    }
  }, "+56 9 5900 3934"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid rgba(255,255,255,0.08)",
      paddingTop: 16,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.xs,
      color: "rgba(255,255,255,0.3)",
      margin: 0
    }
  }, "Celcom S.A. \u2014 Concesionario de Servicios de Telecomunicaciones \xB7 SUBTEL"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: T.typography.scale.xs,
      color: "rgba(255,255,255,0.3)"
    }
  }, "T\xE9rminos y condiciones")))));
}

// ─── CHANNELS TAB ─────────────────────────────────────────
function ChannelsTab() {
  const channels = [{
    name: "WhatsApp API",
    icon: "💬",
    color: C.channels.whatsapp,
    description: "Canal de mensajería bidireccional. Verificación con Green Check disponible.",
    tags: ["Conversacional", "Bidireccional", "API Business", "Green Check"]
  }, {
    name: "SMS Masivo",
    icon: "📱",
    color: C.channels.sms,
    description: "Mensajería A2P instantánea con alta tasa de apertura. Para OTP, alertas y campañas.",
    tags: ["A2P", "Alta apertura", "Transaccional", "Campañas"]
  }, {
    name: "Email Marketing",
    icon: "✉️",
    color: C.brand.accent,
    description: "Correos masivos con analytics. Para newsletters, lanzamientos y lead nurturing.",
    tags: ["Segmentación", "Analytics", "Newsletter", "Nurturing"]
  }, {
    name: "Chatbot",
    icon: "🤖",
    color: C.channels.chatbot,
    description: "Bot conversacional con IA disponible 24/7. Integrable con CRM y omnicanal.",
    tags: ["IA", "24/7", "Omnicanal", "CRM"]
  }, {
    name: "Celcom Flex",
    icon: "⚡",
    color: C.brand.primaryLight,
    description: "Plataforma omnicanal que unifica todos los canales en una sola interfaz.",
    tags: ["Omnicanal", "Plataforma", "Unificado"]
  }, {
    name: "HubSpot Sales",
    icon: "🎯",
    color: C.brand.primary,
    description: "Integración con HubSpot para gestión de ventas y automatización de comunicaciones.",
    tags: ["CRM", "Pipeline", "Automatización"]
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    title: "Identidad de Canales",
    subtitle: "Sistema de color e iconograf\xEDa para cada canal de comunicaci\xF3n."
  }, /*#__PURE__*/React.createElement(Grid, {
    cols: 3,
    gap: 16
  }, channels.map(ch => /*#__PURE__*/React.createElement(Card, {
    key: ch.name,
    style: {
      borderLeft: `4px solid ${ch.color}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 44,
      background: ch.color + "18",
      borderRadius: T.radii.lg,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 22
    }
  }, ch.icon), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      color: C.neutral[900],
      fontSize: T.typography.scale.base,
      margin: 0
    }
  }, ch.name), /*#__PURE__*/React.createElement("code", {
    style: {
      fontSize: T.typography.scale.xs,
      color: ch.color,
      fontWeight: 600
    }
  }, ch.color))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: T.typography.scale.sm,
      color: C.neutral[500],
      lineHeight: 1.6,
      margin: "0 0 12px"
    }
  }, ch.description), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 5
    }
  }, ch.tags.map(t => /*#__PURE__*/React.createElement(Chip, {
    key: t,
    color: ch.color
  }, t))))))), /*#__PURE__*/React.createElement(Section, {
    title: "Comparativa de Canales",
    subtitle: "Gu\xEDa de selecci\xF3n seg\xFAn objetivo y contexto."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: T.radii.xl,
      overflow: "hidden",
      boxShadow: T.shadows.md
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontSize: T.typography.scale.sm
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: C.brand.secondary,
      color: "#fff"
    }
  }, ["Canal", "Objetivo principal", "Entrega", "Apertura est.", "Ideal para"].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: "12px 16px",
      textAlign: "left",
      fontWeight: 600,
      fontSize: T.typography.scale.xs,
      textTransform: "uppercase",
      letterSpacing: "0.06em"
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, [{
    canal: "💬 WhatsApp API",
    obj: "Conversaciones 1:1",
    t: "Inmediata",
    a: "~98%",
    m: "Atención, ventas, soporte"
  }, {
    canal: "📱 SMS Masivo",
    obj: "Alcance masivo",
    t: "Segundos",
    a: "~95%",
    m: "OTP, alertas, campañas"
  }, {
    canal: "✉️ Email",
    obj: "Nutrición de leads",
    t: "Minutos",
    a: "~25%",
    m: "Newsletters, lanzamientos"
  }, {
    canal: "🤖 Chatbot",
    obj: "Automatización 24/7",
    t: "Instant.",
    a: "—",
    m: "FAQ, calificación"
  }].map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      background: i % 2 === 0 ? C.neutral[50] : C.neutral.white
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "12px 16px",
      fontWeight: 600,
      color: C.neutral[900]
    }
  }, r.canal), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "12px 16px",
      color: C.neutral[700]
    }
  }, r.obj), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "12px 16px",
      color: C.neutral[700]
    }
  }, r.t), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "12px 16px",
      color: C.semantic.success,
      fontWeight: 700
    }
  }, r.a), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "12px 16px",
      color: C.neutral[500]
    }
  }, r.m))))))));
}

// ─── APP SHELL ─────────────────────────────────────────────
function DesignSystem() {
  const [active, setActive] = useState("Tokens");
  const tabContent = {
    "Tokens": /*#__PURE__*/React.createElement(TokensTab, null),
    "Tipografía": /*#__PURE__*/React.createElement(TypographyTab, null),
    "Componentes": /*#__PURE__*/React.createElement(ComponentsTab, null),
    "SaaS": /*#__PURE__*/React.createElement(SaaSTab, null),
    "Patrones": /*#__PURE__*/React.createElement(PatternsTab, null),
    "Canales": /*#__PURE__*/React.createElement(ChannelsTab, null)
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: T.typography.families.body,
      background: C.neutral[100],
      minHeight: "100vh"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: C.brand.secondary,
      borderBottom: `3px solid ${C.brand.accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "20px 40px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      background: C.brand.accent,
      borderRadius: T.radii.md,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 900,
      fontSize: 20,
      color: C.brand.secondary,
      fontFamily: T.typography.families.heading
    }
  }, "C"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: T.typography.families.heading,
      fontSize: T.typography.scale["2xl"],
      fontWeight: 800,
      color: "#fff",
      letterSpacing: "-0.02em"
    }
  }, "Celcom"), /*#__PURE__*/React.createElement("span", {
    style: {
      background: C.brand.accent,
      color: C.brand.secondary,
      padding: "2px 10px",
      borderRadius: T.radii.full,
      fontSize: T.typography.scale.xs,
      fontWeight: 700
    }
  }, "Design System v1.1")), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "rgba(255,255,255,0.4)",
      fontSize: T.typography.scale.xs,
      margin: 0
    }
  }, "celcomlatam.com \xB7 6 secciones \xB7 30+ componentes \xB7 35+ tokens"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, [C.brand.primary, C.brand.accent, C.channels.whatsapp, C.channels.chatbot].map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 20,
      height: 20,
      background: c,
      borderRadius: "50%",
      border: "2px solid rgba(255,255,255,0.2)"
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "0 40px",
      display: "flex",
      gap: 4,
      borderTop: "1px solid rgba(255,255,255,0.08)"
    }
  }, navItems.map(n => /*#__PURE__*/React.createElement("button", {
    key: n,
    onClick: () => setActive(n),
    style: {
      padding: "12px 20px",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      fontFamily: T.typography.families.body,
      fontSize: T.typography.scale.sm,
      fontWeight: active === n ? 700 : 500,
      color: active === n ? C.brand.accent : "rgba(255,255,255,0.55)",
      borderBottom: active === n ? `3px solid ${C.brand.accent}` : "3px solid transparent",
      transition: T.motion.fast
    }
  }, n)))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "40px 40px 80px"
    }
  }, tabContent[active]));
}
Object.assign(__ds_scope, { DesignSystem, __ds_default_celcom_design_system_1ert8oh: DesignSystem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "celcom-design-system.jsx", error: String((e && e.message) || e) }); }

// doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * FIRST, decide how the document paginates — up front, before building:
 *
 * - FLOWING document (the default): write the whole document as one
 *   normal HTML flow inside <doc-page>; the browser's print engine
 *   splits it onto pages at export. Use for long-form documents with a
 *   single text flow: reports, memos, letters, essays.
 * - EXPLICIT pagination: a fixed set of pre-paginated pages, one
 *   <section class="page"> child per page. Use when the user asks for a
 *   specific page count, or the design implies one: a one-page resume, a
 *   two-sided flier, a poster, a certificate, a brochure — any richly
 *   laid-out document without a single text flow.
 * - If in doubt, ask the user as part of the build.
 *
 * PAGE SIZING — paper differs by country (letter vs A4), so the printed
 * sheet is not one fixed truth:
 * - FLOWING documents pin NO paper size: the print engine paginates
 *   onto the user's real paper, and the content reflows to it.
 * - EXPLICITLY PAGINATED documents print each page at a FIXED page box
 *   with overflow hidden — letter by default, size="a4" for a clearly
 *   metric user, the user's chosen paper when they export. Design each
 *   page to FILL that box, fitting letter and A4 alike without overlap.
 * - width/height pin an explicit fixed size, ONLY when the user gives
 *   one.
 * Never write your own @page rule or hard-code paper dimensions in the
 * content.
 *
 * Sizing modes (attributes):
 *   (none)                      — portrait: flowing docs use the user's
 *           paper; explicitly paginated pages use the named size box
 *           (letter unless size="a4")
 *   orientation="landscape"     — the same, landscape
 *   width / height              — explicit fixed size, ONLY when the user
 *           gives one (e.g. width="22in" height="30in" for a 22×30
 *           poster): the page IS the design's size, printed at true
 *           dimensions (or scaled onto the user's paper at print time).
 *           Any absolute CSS length: px/in/mm/cm/pt/pc.
 * The component announces the chosen mode to the host app at runtime (a
 * meta tag it injects), so the print path can inject the user's true
 * paper size.
 *
 * On screen the document renders on a desk background: a flowing
 * document as one tall scrolling sheet (Google Docs' pageless view);
 * explicitly paginated documents as one card per page.
 *
 * EXPLICIT pagination usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page>
 *     <section class="page" id="p1">…one page's design…</section>
 *     <section class="page" id="p2">…</section>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * How the page box works, concretely: each .page prints as ONE full-bleed
 * sheet at a FIXED physical size — letter by default (set size="a4" for
 * a clearly metric user), the user's chosen paper when they export —
 * with overflow hidden. Nothing scrolls and nothing reflows onto a next
 * sheet: content that misses the box is CLIPPED. Design each page to
 * FILL that page box, and to fit it — letter and A4 alike — without
 * overlap. Each page is a size container; don't size anything in
 * viewport units (they track the window, not the page), and never set
 * width or height on the .page section itself (the component sizes the
 * page box; an authored height like 100% is meaningless at print and is
 * overridden). The component owns the page box, the screen card chrome,
 * and the page breaks (never add your own break-before/after). Don't mix
 * .page sections with flowing content or header/footer slots in the same
 * document.
 *
 * FLOWING usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * There is no manual page-splitting — the browser's print engine
 * paginates at export. Standard break-hygiene rules (`break-inside:
 * avoid` on figures, code blocks, images and table rows; `orphans/
 * widows: 3`) are applied so paragraphs and groups split cleanly. On
 * screen and at print, headings default to `text-wrap: balance` and
 * body text to `text-wrap: pretty`; the defaults have zero specificity,
 * so any text-wrap you declare wins.
 *
 * Other attributes:
 *   size    — letter | a4 | legal (default letter). Flowing documents:
 *           preview proportion only — it does NOT pin their printed
 *           paper (the print dialog's paper governs); leave it alone
 *           there. Explicitly paginated documents: it sets the page box
 *           the cards and the pinned @page share (the export dialog's
 *           choice overrides both at print) — set size="a4" for a
 *           clearly metric user. Scaled-fit: names the sheet the fit is
 *           computed against, same a4-for-metric-users advice.
 *   content-width / content-height — the design's own fixed dimensions
 *           (CSS lengths), for scaling a fixed-size design ONTO the
 *           named sheet: content lays out at exactly this size, and the
 *           component scales it to fit that sheet's printable area
 *           (centered horizontally, top-aligned; the export dialog
 *           re-fits to the user's actual paper choice where available).
 *           Both must be set; they do not change the page box. For pages
 *           WITHOUT running header/footer slots.
 *   margin  — printable inset on every page of a FLOWING document
 *           (default 0.75in); margin="0" makes pages full-bleed.
 *           Explicitly paginated pages are always full-bleed.
 *
 * Running header/footer (flowing documents only): give an element
 * `slot="header"` or `slot="footer"` and it repeats on every printed
 * page via `position: fixed`. To keep body text from sliding under it,
 * the component prints inside a single-cell table whose <thead>/<tfoot>
 * are spacers sized to the header/footer height — browsers repeat
 * thead/tfoot on every page, so each sheet's content starts below the
 * header and ends above the footer. On screen the header/footer render
 * once at the top/bottom of the sheet.
 *
 * At print the component injects `@page { margin: 0 }` (which leaves
 * Chrome no margin box to draw its date/URL/page-count header in) and
 * moves the visual margin onto the sheet's own padding. It also marks
 * the document as owning its print CSS (a
 * `meta[name="omelette-owns-print"]` it injects at runtime), so the
 * PDF export never injects page-geometry CSS of its own on top.
 *
 * Print best practices for the content you author:
 * - Multi-column text: use CSS columns (`column-count` +
 *   `column-gap`), never side-by-side flex/grid columns — only real
 *   CSS columns flow and break across pages. `column-span: all` lets
 *   a heading span the columns; `hyphens: auto` (needs `lang` on
 *   the html element) keeps narrow columns readable.
 * - Page breaks in flowing documents: `break-before: page` on an
 *   element that must start a new page (a chapter, an appendix). Add
 *   your own kept-together blocks (callouts, stat tiles, cards) to a
 *   `break-inside: avoid` rule, and keep each one shorter than a page.
 * - Extend `orphans: 3; widows: 3` to any custom text blocks you add
 *   (p and li are covered by default).
 * - Give long tables a <thead> — browsers repeat it on every printed
 *   page.
 * - No `position: fixed`/`sticky` and no viewport units in content:
 *   fixed elements stamp every printed page (running headers/footers go
 *   in the component's slots) and `100vh` mis-sizes at print.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  // Unitless "0" is a valid CSS length and the natural way to write
  // margin="0"; normalise it to 0px so max()/calc() (which reject a bare
  // number) keep working.
  const safeLen = (v, fb) => {
    v = (v || '').trim();
    return v === '0' ? '0px' : CSS_LENGTH.test(v) ? v : fb;
  };
  // WebKit (Safari and every iOS browser shell) never repeats a table's
  // thead/tfoot on printed pages (WebKit bug 17205), so the spacer-borne
  // vertical margins of a FLOWING document reach only the first page
  // there. Engine check, not browser check: vendor is 'Apple Computer,
  // Inc.' exactly for WebKit and 'Google Inc.' for Blink.
  const WK_PRINT = /apple/i.test(navigator.vendor || '');
  // CSS length → px number (CSS absolute units are exact: 1in = 96px).
  // Returns NaN for anything safeLen would reject — callers gate on it.
  const PX_PER = {
    px: 1,
    in: 96,
    mm: 96 / 25.4,
    cm: 96 / 2.54,
    pt: 96 / 72,
    pc: 16
  };
  const toPx = v => {
    const m = /^(\d+(?:\.\d+)?)(px|in|mm|cm|pt|pc)$/.exec((v || '').trim());
    return m ? parseFloat(m[1]) * PX_PER[m[2]] : NaN;
  };
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      /* When the viewport is narrower than the page, grow to wrap the
       * sheet (plus this padding) instead of staying viewport-width, so
       * the desk background and right margin reach the sheet's far edge
       * in the horizontal scroll. */
      min-width: max-content;
      min-height: 100vh;
      background: #f5f5f4;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
      --doc-hdr-pad: 0px;
      --doc-ftr-pad: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 10px rgba(20, 20, 19, 0.12);
      border-radius: 7px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    /* Scaled-fit mode (content-width/content-height): the inner .fit box
     * lays the content out at its authored fixed size and scales it onto
     * the printable area; .fit-box reserves the scaled footprint in flow
     * (transforms don't affect layout) and centers it. Without the mode,
     * both divs are unstyled block pass-throughs. */
    /* Explicit pagination: direct .page children are the pages. The sheet
     * becomes a transparent stack and each page carries the card look on
     * screen; at print each page is exactly one full-bleed sheet. The
     * ::slotted defaults are deliberately weak (document CSS wins), so
     * authored page styling can override any of this. */
    .sheet.paginated {
      background: transparent;
      box-shadow: none;
      border-radius: 0;
      padding: 0;
    }
    .paginated ::slotted(.page) {
      position: relative;
      display: block;
      width: 100%;
      aspect-ratio: var(--doc-page-ar);
      container-type: size;
      overflow: hidden;
      box-sizing: border-box;
      background: #fff;
      border-radius: 7px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
      break-inside: avoid;
    }
    .paginated ::slotted(.page:not(:first-child)) { margin-top: 1rem; }
    @media print {
      .sheet.paginated { padding: 0; }
      /* The flowing-document vertical inset lives on the repeating
       * thead/tfoot spacers, not the sheet padding — they must go too,
       * or each full-sheet .page is pushed ~margin down and spills onto
       * a second sheet. Paginated pages are full-bleed by definition
       * (content owns its insets). */
      .sheet.paginated .hdr-space,
      .sheet.paginated .ftr-space { height: 0; }
      .paginated ::slotted(.page) {
        border-radius: 0 !important;
        box-shadow: none !important;
        margin: 0 !important;
        /* Physical page-box sizing, no viewport units: Safari resolves
         * 100vh against the window, not the page box, so a vh-sized card
         * paginates wrong there. --doc-page-w/h are the named size by
         * default and are overridden to the user's chosen paper by the
         * export path, so every card is exactly one sheet either way.
         * Width + height (same source values as @page size) rather than
         * width + aspect-ratio: the ratio is a 6-decimal rounding of the
         * same division, and a few millionths of overflow would spill a
         * blank sheet after every page. The screen-only aspect-ratio
         * (preview proportions) must not leak into print. cqh typography
         * tracks the same box.
         *
         * Every declaration is !important: per CSS Scoping, unimportant
         * shadow ::slotted rules LOSE to the document context, so a page
         * section's authored inline style would silently beat this print
         * geometry. A model-authored height:100% did exactly that — the
         * percentage resolves as auto in the all-auto print ancestry, the
         * base rule's size containment turns auto into ZERO, and
         * overflow:hidden then paints nothing: a blank PDF with perfect
         * page boxes. At print the component's geometry is the design's
         * whole contract, so it must win over any authored sizing. */
        aspect-ratio: auto !important;
        width: var(--doc-page-w) !important;
        height: var(--doc-page-h) !important;
        overflow: hidden !important;
      }
      .paginated ::slotted(.page:not(:first-child)) {
        break-before: page !important;
        margin-top: 0 !important;
      }
    }
    .fit-mode .fit-box {
      width: calc(var(--doc-fit-w) * var(--doc-fit-scale));
      height: calc(var(--doc-fit-h) * var(--doc-fit-scale));
      margin: 0 auto;
      break-inside: avoid;
    }
    .fit-mode .fit {
      width: var(--doc-fit-w);
      height: var(--doc-fit-h);
      transform: scale(var(--doc-fit-scale));
      transform-origin: top left;
    }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-width: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      /* The 0.35in is breathing room between a running header/footer and
       * the body; without one the spacer is exactly the page margin, so a
       * margin="0" full-bleed document gets truly full-bleed pages. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))); }
      /* WebKit flowing documents: @page carries the vertical margin (see
       * _syncPrintPageRule), so the spacers keep only whatever a running
       * header/footer needs BEYOND it — page 1 would otherwise double its
       * top inset. Paginated sheets already zero their spacers above. */
      .sheet.wk-print:not(.paginated) .hdr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))) - var(--doc-page-margin))); }
      .sheet.wk-print:not(.paginated) .ftr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))) - var(--doc-page-margin))); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin', 'orientation', 'content-width', 'content-height'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }

    /** The named paper's [w, h], swapped when orientation="landscape".
     *  Only the named size swaps — explicit width/height are exact values
     *  the author already oriented. */
    _paperSize() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()] || PAPER.letter;
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? [named[1], named[0]] : named;
    }
    get pageWidth() {
      return safeLen(this.getAttribute('width'), this._paperSize()[0]);
    }
    get pageHeight() {
      return safeLen(this.getAttribute('height'), this._paperSize()[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }

    /** Scaled-fit mode's content box [w, h] as CSS lengths, or null when
     *  the mode is off (either attribute missing/invalid/zero — a partial
     *  declaration falls back to normal flow rather than guessing). */
    _contentFit() {
      const w = safeLen(this.getAttribute('content-width'), null);
      const h = safeLen(this.getAttribute('content-height'), null);
      if (!w || !h) return null;
      const wPx = toPx(w),
        hPx = toPx(h);
      return wPx > 0 && hPx > 0 ? [w, h, wPx, hPx] : null;
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      this._ensureTextWrapDefaults();
      this._ensureOwnsPrintMeta();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rules when the last doc-page leaves, so a deleted
      // document's @page geometry and text-wrap defaults can't apply to
      // whatever replaces it.
      const survivor = document.querySelector('doc-page');
      if (!survivor) {
        ['doc-page-print', 'doc-page-text-wrap', 'doc-page-owns-print', 'doc-page-fixed-size', 'doc-page-print-sizing'].forEach(id => {
          const tag = document.getElementById(id);
          if (tag) tag.remove();
        });
        // A live deck-stage deferred its own print-sizing meta to ours —
        // hand the page-global meta over so the deck isn't left unmarked.
        const deck = document.querySelector('deck-stage');
        if (deck && typeof deck._ensurePrintSizingMeta === 'function') {
          deck._ensurePrintSizingMeta();
        }
      } else {
        // A departed owner hands each page-global meta to whatever
        // doc-page remains (or it's removed).
        if (typeof survivor._syncFixedSizeMeta === 'function') {
          survivor._syncFixedSizeMeta();
        }
        if (typeof survivor._syncPrintSizingMeta === 'function') {
          survivor._syncPrintSizingMeta();
        }
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><div class="fit-box"><div class="fit"><slot></slot></div></div></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      // Scaled-fit mode: content at its authored size, scaled onto the
      // printable area (page minus margins on both axes). The factor is a
      // plain number var so calc(length * number) stays valid; 4 decimals
      // keeps the shadow style stable across re-measures. Upscaling is
      // allowed — print transforms are vector, so text and CSS stay crisp
      // (raster images soften, which the catalog bullet warns about).
      const fit = this._contentFit();
      let fitVars = '';
      if (fit) {
        const marginPx = toPx(this.pageMargin) || 0;
        const availW = toPx(this.pageWidth) - 2 * marginPx;
        const availH = toPx(this.pageHeight) - 2 * marginPx;
        const scale = Math.min(availW / fit[2], availH / fit[3]);
        if (scale > 0 && Number.isFinite(scale)) {
          fitVars = '--doc-fit-w:' + fit[0] + ';' + '--doc-fit-h:' + fit[1] + ';' + '--doc-fit-scale:' + scale.toFixed(4) + ';';
        }
      }
      this._sheet.classList.toggle('fit-mode', !!fitVars);
      // Numeric w/h ratio for the paginated page cards' aspect-ratio —
      // aspect-ratio takes a number, not a length ratio, so compute it
      // here (CSS length division isn't portable). 6 decimals keeps the
      // shadow style stable across re-syncs.
      const arW = toPx(this.pageWidth);
      const arH = toPx(this.pageHeight);
      const ar = arW > 0 && arH > 0 ? (arW / arH).toFixed(6) : '0.772727';
      this._vars.textContent = ':host{' + fitVars + '--doc-page-ar:' + ar + ';' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px;' + '--doc-hdr-pad:' + (hdrH ? '0.35in' : '0px') + ';' + '--doc-ftr-pad:' + (ftrH ? '0.35in' : '0px') + '}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document.
     *
     *  The @page SIZE is pinned where the page box IS part of the design:
     *  explicit-fixed-size mode (width + height authored), scaled-fit
     *  mode (the named sheet the fit targets), and explicit pagination
     *  (the named size the cards share — so card and sheet agree on
     *  every print path, and the export path's chosen paper overrides
     *  BOTH with one later rule). For FLOWING documents no paper size is
     *  emitted at all — the true size comes from the user's preference,
     *  injected by the export path or chosen in the print dialog — so a
     *  flowing document never fights the paper it lands on.
     *  margin: 0 is emitted in every mode: it leaves Chrome no margin box
     *  to draw its date/URL/page-count header in, and the visual margin
     *  lives on the sheet's own padding. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      // Three print-geometry regimes:
      // - true-size: the page IS the design — pin its exact size.
      // - scaled-fit (content-width/height): the fit factor is computed
      //   against the NAMED paper's printable area, so that paper must
      //   stay pinned or the scaled content overflows a smaller sheet
      //   (the export path re-fits and re-pins at print time on top).
      // - default modes: no paper size — but landscape still needs the
      //   paper-agnostic 'size: landscape' keyword, because the size
      //   descriptor is what carries orientation; without it a landscape
      //   document prints portrait whenever nothing injects a size.
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      // Explicit pagination pins the page box to the SAME values that
      // size the cards (the named size by default, the export path's
      // chosen paper when its later rule overrides both) — card and
      // sheet agree on every print path, and a mismatched real paper
      // shrinks-to-fit in the dialog instead of clipping a Letter card
      // on A4. Declared before the paginated read below so both derive
      // from one check.
      const paginatedNow = this.querySelector(':scope > .page') !== null;
      const sizeDescriptor = this._trueSizePx() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : this._contentFit() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : paginatedNow ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : landscape ? 'size: landscape; ' : '';
      // WebKit never repeats the thead/tfoot spacers that carry a flowing
      // document's vertical page margins (see WK_PRINT above), so pages
      // after the first print edge-to-edge there. Carry the VERTICAL
      // margins on @page for WebKit instead, and the shadow print CSS
      // trims the first-page spacers by the same amount (.sheet.wk-print
      // rules). Horizontal inset stays on the sheet's own padding in
      // every engine. Blink keeps margin: 0 (a nonzero margin there
      // re-opens the box Chrome draws its header furniture in). One cost,
      // learned in testing: Safari's own date/URL headers are a USER
      // dialog setting ("Print headers and footers") that renders in the
      // margin area when room exists — margin: 0 only suppressed it by
      // leaving no room, and no CSS controls it. The export dialog's
      // Safari guide teaches turning the setting off for flowing
      // documents. Explicitly paginated and fixed-size documents keep
      // margin: 0 everywhere: their pages ARE the sheet.
      const wkFlowing = WK_PRINT && !paginatedNow && !this._trueSizePx() && !this._contentFit();
      const marginDescriptor = wkFlowing ? 'margin: ' + this.pageMargin + ' 0; ' : 'margin: 0; ';
      // Shadow-internal marker (never serialized), kept in lockstep with
      // the @page decision above: the print CSS trims the first-page
      // spacers ONLY while @page actually carries the margins — a
      // true-size or scaled-fit sheet keeps margin: 0 and must keep its
      // spacers too. Re-synced here so attribute changes and pagination
      // flips move both together.
      if (this._sheet) this._sheet.classList.toggle('wk-print', wkFlowing);
      tag.textContent = '@page { ' + sizeDescriptor + marginDescriptor + '} ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; ' + 'backdrop-filter: none !important; -webkit-backdrop-filter: none !important; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }

    /** Typographic defaults for document text: balance headings, avoid
     *  widowed/orphaned words in body copy (browsers without text-wrap
     *  support drop the declarations). Zero-specificity via :where() so
     *  any text-wrap authored on those elements wins; document-level so the
     *  rules reach the slotted (light DOM) content — shadow styles can't.
     *  data-omelette-injected marks the tag for the host editor to strip
     *  at serialize, so it is never written back as authored source. */
    _ensureTextWrapDefaults() {
      if (document.getElementById('doc-page-text-wrap')) return;
      const tag = document.createElement('style');
      tag.id = 'doc-page-text-wrap';
      tag.setAttribute('data-omelette-injected', '');
      tag.textContent = ':where(h1,h2,h3,h4,h5,h6){text-wrap:balance}' + ':where(p,li,blockquote,figcaption){text-wrap:pretty}';
      document.head.appendChild(tag);
    }

    /** Declares that this document owns its print CSS. The instant-PDF
     *  export checks for the meta by NAME PRESENCE alone (content is
     *  ignored) and skips its automatic print-CSS injections, so the
     *  component's @page geometry is never overridden by a heuristic.
     *  data-omelette-injected keeps it out of serialized source. */
    _ensureOwnsPrintMeta() {
      if (document.getElementById('doc-page-owns-print')) return;
      const tag = document.createElement('meta');
      tag.id = 'doc-page-owns-print';
      tag.name = 'omelette-owns-print';
      tag.content = 'true';
      tag.setAttribute('data-omelette-injected', '');
      document.head.appendChild(tag);
    }

    /** This page's valid true-size page box (explicit width AND height)
     *  as [w, h] px ints, or null when the mode is off. */
    _trueSizePx() {
      if (!safeLen(this.getAttribute('width'), null) || !safeLen(this.getAttribute('height'), null)) return null;
      const w = Math.round(toPx(this.pageWidth));
      const h = Math.round(toPx(this.pageHeight));
      return w > 0 && h > 0 ? [w, h] : null;
    }

    /** True-size pages (explicit width AND height) also declare the page
     *  box as the preview size: the in-app preview reads
     *  meta[name="omelette-fixed-size"] (content "W,H" in px ints) and
     *  scales the sheet into view — without it an 18in poster previews at
     *  true size with scrollbars. Never overrides an author-set meta
     *  (only the component's own id is managed). The meta is page-global
     *  while doc-page instances are not, so every sync recomputes the
     *  page-wide owner — the first connected true-size doc-page — and a
     *  non-true-size sibling's sync can never delete the owner's meta.
     *  Removed when no true-size page remains (the owner's disconnect
     *  re-syncs via any survivor) or when an author-set meta exists. */
    _syncFixedSizeMeta() {
      const id = 'doc-page-fixed-size';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-fixed-size"]:not([data-omelette-injected])');
      // The page-wide owner, not this instance: an upgraded true-size page
      // anywhere in the document keeps the meta alive and sized.
      let box = null;
      for (const el of document.querySelectorAll('doc-page')) {
        box = typeof el._trueSizePx === 'function' ? el._trueSizePx() : null;
        if (box) break;
      }
      if (!box || authored) {
        if (own) own.remove();
        return;
      }
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-fixed-size';
      tag.content = box[0] + ',' + box[1];
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }

    /** This page's print-sizing mode: 'fixed' when an explicit width AND
     *  height are authored (the page is the design's own size), else the
     *  default paper in the authored orientation. */
    _printSizingMode() {
      if (this._trueSizePx()) return 'fixed';
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? 'default-landscape' : 'default-portrait';
    }

    /** Announces the print-sizing mode to the host app:
     *  meta[name="omelette-print-sizing"] with content 'default-portrait',
     *  'default-landscape', or 'fixed' (fixed pages also carry the
     *  omelette-fixed-size meta with the page box in px). The export path
     *  probes it to decide what true paper size to inject at print time —
     *  in the default modes the component emits no paper size of its own.
     *  Same page-global ownership rules as the fixed-size meta above:
     *  first connected doc-page owns it, an authored meta is never
     *  overridden, removed when no doc-page remains. */
    _syncPrintSizingMeta() {
      const id = 'doc-page-print-sizing';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-print-sizing"]:not([data-omelette-injected])');
      // A fixed page wins outright (mirroring the fixed-size loop above,
      // so the two metas can never contradict each other in a mixed
      // multi-page document); otherwise the first page's mode holds.
      let mode = null;
      for (const el of document.querySelectorAll('doc-page')) {
        if (typeof el._printSizingMode !== 'function') continue;
        const m = el._printSizingMode();
        if (m === 'fixed') {
          mode = m;
          break;
        }
        if (mode === null) mode = m;
      }
      if (!mode || authored) {
        if (own) own.remove();
        return;
      }
      // A deck-stage that connected first injected its own meta and
      // defers to any existing one — take it over, or the document ends
      // up with two conflicting injected metas (a doc-page page is the
      // document; the deck re-ensures its meta if every doc-page leaves).
      const deckMeta = document.getElementById('deck-stage-print-sizing');
      if (deckMeta) deckMeta.remove();
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-print-sizing';
      tag.content = mode;
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. The
     *  same pass detects explicit pagination (direct .page children) and
     *  toggles the sheet between the flowing-document card and the
     *  page-per-card stack — content edits can add or remove pages at any
     *  time, so this tracks the same mutations the measurement does. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      const wasPaginated = this._sheet.classList.contains('paginated');
      this._sheet.classList.toggle('paginated', this.querySelector(':scope > .page') !== null);
      // The WebKit @page margin is flowing-only, so a pagination flip
      // must re-emit the rule (content edits can add or remove .page
      // sections at any time).
      if (this._sheet.classList.contains('paginated') !== wasPaginated) {
        this._syncPrintPageRule();
      }
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "doc-page.js", error: String((e && e.message) || e) }); }

// ui_kits/platform/ChatbotPages.jsx
try { (() => {
function ChatbotDetail({
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: "none",
      border: "none",
      color: "#7A8EAD",
      fontSize: 12,
      cursor: "pointer",
      padding: 0,
      marginBottom: 16,
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M15 18l-6-6 6-6"
  })), "Chatbots"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 20,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.01em"
    }
  }, "Asistente Farmacia Central"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "4px 0 0"
    }
  }, "Bot Sucursal Centro \xB7 +56 2 2345 6789 \xB7 N8N ID ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: "'Fira Code',monospace",
      background: "#F4F6FB",
      padding: "1px 5px",
      borderRadius: 4
    }
  }, "wf_fc_001"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#15803D",
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "5px 10px",
      background: "#fff",
      border: "1px solid #EEF1F6",
      borderRadius: 9999
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: "#15803D"
    }
  }), "N8N activo"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "Guardar cambios"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 16px"
    }
  }, "Datos del bot"), /*#__PURE__*/React.createElement(Field, {
    label: "Nombre del bot",
    value: "Asistente Farmacia Central"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Idioma",
    value: "Espa\xF1ol (Chile)"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Tono",
    value: "Profesional y cercano"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Prompt del sistema"), /*#__PURE__*/React.createElement("textarea", {
    defaultValue: "Eres el asistente virtual de Farmacia Central. Tu objetivo es ayudar a los clientes con consultas sobre medicamentos, horarios de sucursales y disponibilidad. Responde en espa\xF1ol, con tono amable. Si el cliente solicita hablar con una persona, escala la conversaci\xF3n.",
    style: {
      ...inp,
      height: 100,
      resize: "none",
      fontFamily: "Inter",
      lineHeight: 1.5
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Fuente de conocimiento (Google Drive)"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    defaultValue: "Base_Conocimiento_FC_v3.pdf",
    style: {
      ...inp,
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: btnSec
  }, "Cambiar")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#9AACC8",
      margin: "6px 0 0"
    }
  }, "\xDAltima sincronizaci\xF3n: hace 2 horas"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "20px 22px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 12px"
    }
  }, "Estado de integraciones"), [{
    label: "N8N workflow: activo y sin errores",
    ok: true
  }, {
    label: "Gupshup: +56 2 2345 6789 conectado",
    ok: true
  }, {
    label: "Google Drive: sincronizado (hace 2h)",
    ok: true
  }].map((i, k) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "8px 10px",
      background: "#F6FBF5",
      borderRadius: 7,
      marginBottom: 6,
      fontSize: 12,
      color: "#15803D"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 13l4 4L19 7"
  })), i.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "20px 22px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 14px"
    }
  }, "L\xEDmites y consumo"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 6,
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#3A4A6B"
    }
  }, "Este mes"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: "#0D1B33",
      fontFeatureSettings: "'tnum'"
    }
  }, "4.412 / 5.000")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#F4F6FB",
      borderRadius: 9999,
      height: 5,
      overflow: "hidden",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "88%",
      height: "100%",
      background: "#D97706"
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#B45309",
      margin: "0 0 14px"
    }
  }, "Alerta activada al 80% \u2014 excedente estimado: 180 conv."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Tope mensual",
    value: "5000"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Alerta al (%)",
    value: "80"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "20px 22px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 12px"
    }
  }, "Historial de versiones"), [{
    date: "10 abr",
    author: "Carlos M.",
    change: "Actualización prompt"
  }, {
    date: "02 abr",
    author: "Fernanda R.",
    change: "Nueva base conocimiento"
  }, {
    date: "01 feb",
    author: "Carlos M.",
    change: "Creación inicial"
  }].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "9px 0",
      borderBottom: i < 2 ? "1px solid #F4F6FB" : "none",
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#7A8EAD"
    }
  }, h.date, " \xB7 ", h.author), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#0D1B33"
    }
  }, h.change)))))));
}
const lbl = {
  fontSize: 11,
  fontWeight: 600,
  color: "#3A4A6B",
  display: "block",
  marginBottom: 6,
  textTransform: "uppercase",
  letterSpacing: ".04em"
};
const inp = {
  width: "100%",
  padding: "9px 12px",
  borderRadius: 7,
  border: "1px solid #EEF1F6",
  background: "#FAFBFD",
  fontSize: 13,
  fontFamily: "Inter",
  color: "#0D1B33",
  boxSizing: "border-box",
  outline: "none"
};
const btnSec = {
  background: "#fff",
  color: "#3A4A6B",
  border: "1px solid #EEF1F6",
  padding: "8px 14px",
  borderRadius: 7,
  fontWeight: 500,
  fontSize: 12,
  cursor: "pointer",
  fontFamily: "Inter"
};
function Field({
  label,
  value,
  placeholder
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, label), /*#__PURE__*/React.createElement("input", {
    defaultValue: value,
    placeholder: placeholder,
    style: inp
  }));
}
function ChatbotOnboarding({
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: "none",
      border: "none",
      color: "#7A8EAD",
      fontSize: 12,
      cursor: "pointer",
      padding: 0,
      marginBottom: 16,
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M15 18l-6-6 6-6"
  })), "Chatbots"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 20,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.01em"
    }
  }, "Nuevo chatbot"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "4px 0 0"
    }
  }, "Configura empresa, plan, bot y administrador en un solo flujo.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: btnSec
  }, "Cancelar"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "Crear y enviar accesos"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Step, {
    n: 1,
    title: "Datos de la empresa"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nombre de la empresa *",
    placeholder: "Ej: Cl\xEDnica del Sol SpA"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "RUT *",
    placeholder: "76.XXX.XXX-X"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Contacto principal *",
    placeholder: "Nombre completo"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email *",
    placeholder: "contacto@empresa.cl"
  }))), /*#__PURE__*/React.createElement(Step, {
    n: 2,
    title: "Plan y configuraci\xF3n comercial"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Plan contratado *"), /*#__PURE__*/React.createElement("select", {
    style: inp
  }, /*#__PURE__*/React.createElement("option", null, "V2 \u2014 Plataforma de Clientes"), /*#__PURE__*/React.createElement("option", null, "V1 \u2014 B\xE1sico"), /*#__PURE__*/React.createElement("option", null, "V3 \u2014 Enterprise"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Ejecutivo Celcom *"), /*#__PURE__*/React.createElement("select", {
    style: inp
  }, /*#__PURE__*/React.createElement("option", null, "Carlos Merino"), /*#__PURE__*/React.createElement("option", null, "Ana Morales"))), /*#__PURE__*/React.createElement(Field, {
    label: "Fecha de inicio *",
    value: "2026-04-22"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Tope mensual conversaciones",
    placeholder: "5000"
  }))), /*#__PURE__*/React.createElement(Step, {
    n: 3,
    title: "Configuraci\xF3n del bot inicial"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nombre del bot",
    placeholder: "Ej: Asistente Cl\xEDnica del Sol"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "N\xFAmero WhatsApp *",
    placeholder: "+56 2 XXXX XXXX"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Prompt inicial del sistema"), /*#__PURE__*/React.createElement("textarea", {
    placeholder: "Rol, objetivo, tono y restricciones del bot...",
    style: {
      ...inp,
      height: 80,
      resize: "none",
      fontFamily: "Inter"
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Base de conocimiento (Google Drive)"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "URL del archivo en Google Drive",
    style: {
      ...inp,
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: btnSec
  }, "Vincular")))), /*#__PURE__*/React.createElement(Step, {
    n: 4,
    title: "Usuario administrador del cliente"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nombre *",
    placeholder: "Nombre del administrador"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email *",
    placeholder: "admin@empresa.cl"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "10px 14px",
      background: "#FAFBFD",
      border: "1px solid #EEF1F6",
      borderRadius: 7,
      fontSize: 12,
      color: "#3A4A6B"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#7A8EAD",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 16v-4M12 8h.01"
  })), "El usuario recibir\xE1 un email con sus credenciales de acceso al portal una vez creado."))));
}
function Step({
  n,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: "50%",
      background: "#E7EEF8",
      color: "#0057B8",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 11,
      fontWeight: 700
    }
  }, n), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, title)), children);
}
function ChatbotMonitor({
  onBack
}) {
  const clients = [{
    name: "MegaRetail SpA",
    plan: "V2",
    state: "Activo",
    conv: 4230,
    cap: 5000
  }, {
    name: "Farmacia Central",
    plan: "V2",
    state: "Alerta",
    conv: 4412,
    cap: 5000
  }, {
    name: "Inmobiliaria Norte",
    plan: "V1",
    state: "Activo",
    conv: 890,
    cap: 2000
  }, {
    name: "TecnoServicios",
    plan: "V2",
    state: "Suspendido",
    conv: null,
    cap: 3000
  }];
  const stColor = {
    Activo: "#15803D",
    Alerta: "#D97706",
    Suspendido: "#B91C1C"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: "none",
      border: "none",
      color: "#7A8EAD",
      fontSize: 12,
      cursor: "pointer",
      padding: 0,
      marginBottom: 16,
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M15 18l-6-6 6-6"
  })), "Chatbots"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 20,
      fontWeight: 700,
      color: "#0D1B33",
      margin: "0 0 4px",
      letterSpacing: "-0.01em"
    }
  }, "Monitor global"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "0 0 22px"
    }
  }, "Estado consolidado de todos los clientes contratantes."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 14,
      marginBottom: 20
    }
  }, [{
    label: "Clientes activos",
    value: "24",
    hint: "+2 este mes",
    up: true
  }, {
    label: "Conversaciones hoy",
    value: "1.847",
    hint: "+12% vs ayer",
    up: true
  }, {
    label: "Resolución auto.",
    value: "78%",
    hint: "+3pp este mes",
    up: true
  }, {
    label: "Alertas pendientes",
    value: "4",
    hint: "2 sobre 80%",
    warn: true
  }].map((k, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "18px 20px",
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "0 0 10px"
    }
  }, k.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontSize: 24,
      fontWeight: 700,
      color: k.warn ? "#B45309" : "#0D1B33",
      margin: 0,
      letterSpacing: "-0.02em"
    }
  }, k.value), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: k.warn ? "#B45309" : "#15803D",
      margin: "4px 0 0"
    }
  }, k.up ? "↑ " : k.warn ? "⚠ " : "", k.hint)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 340px",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 24px",
      borderBottom: "1px solid #EEF1F6",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Clientes \u2014 estado general")), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "#FAFBFD"
    }
  }, ["Empresa", "Plan", "Estado", "Consumo", "Tope", ""].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: "left",
      padding: "11px 24px",
      fontSize: 11,
      color: "#7A8EAD",
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: ".05em"
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, clients.map((c, i) => {
    const pct = c.conv ? Math.round(c.conv / c.cap * 100) : 0;
    return /*#__PURE__*/React.createElement("tr", {
      key: i,
      style: {
        borderTop: "1px solid #F4F6FB"
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px",
        fontSize: 13,
        fontWeight: 600,
        color: "#0D1B33"
      }
    }, c.name), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#F4F6FB",
        color: "#3A4A6B",
        fontSize: 11,
        fontWeight: 500,
        padding: "3px 9px",
        borderRadius: 6
      }
    }, c.plan)), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px",
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: stColor[c.state],
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        fontWeight: 500
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "50%",
        background: stColor[c.state]
      }
    }), c.state, c.state === "Alerta" && " 88%")), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px",
        fontSize: 13,
        color: "#3A4A6B",
        fontFeatureSettings: "'tnum'"
      }
    }, c.conv ? c.conv.toLocaleString() : "—"), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px",
        fontSize: 13,
        color: "#7A8EAD",
        fontFeatureSettings: "'tnum'"
      }
    }, c.cap.toLocaleString()), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "14px 24px"
      }
    }, /*#__PURE__*/React.createElement("button", {
      style: {
        background: "none",
        border: "none",
        color: "#0057B8",
        fontSize: 12,
        fontWeight: 500,
        cursor: "pointer"
      }
    }, "Ver")));
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "20px 22px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 14px"
    }
  }, "Salud del sistema"), [{
    text: "N8N: 24/24 bots activos",
    ok: true
  }, {
    text: "Gupshup API: operativo",
    ok: true
  }, {
    text: "2 clientes sobre 80% tope",
    warn: true
  }, {
    text: "Google Drive: sincronizado",
    ok: true
  }].map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "9px 10px",
      background: s.warn ? "#FFF7E0" : "#F6FBF5",
      borderRadius: 7,
      marginBottom: 6,
      fontSize: 12,
      color: s.warn ? "#B45309" : "#15803D"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, s.warn ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 2L2 20h20L12 2z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 10v4M12 18h.01"
  })) : /*#__PURE__*/React.createElement("path", {
    d: "M5 13l4 4L19 7"
  })), s.text)))));
}
window.CelcomChatbotDetail = ChatbotDetail;
window.CelcomChatbotOnboarding = ChatbotOnboarding;
window.CelcomChatbotMonitor = ChatbotMonitor;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/ChatbotPages.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/Dashboard.jsx
try { (() => {
function Dashboard() {
  const kpis = [{
    icon: "sms",
    label: "SMS enviados",
    value: "47.320",
    delta: "12%",
    up: true
  }, {
    icon: "chat",
    label: "Conversaciones",
    value: "8.941",
    delta: "8%",
    up: true
  }, {
    icon: "mail",
    label: "Emails entregados",
    value: "23.100",
    delta: "3%",
    up: false
  }, {
    icon: "bot",
    label: "Chatbot hits",
    value: "11.500",
    delta: "21%",
    up: true
  }];
  const Ic = ({
    name
  }) => {
    const p = {
      sms: /*#__PURE__*/React.createElement("path", {
        d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
      }),
      chat: /*#__PURE__*/React.createElement("path", {
        d: "M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"
      }),
      mail: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "3",
        y: "5",
        width: "18",
        height: "14",
        rx: "2"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M3 7l9 6 9-6"
      })),
      bot: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "4",
        y: "8",
        width: "16",
        height: "12",
        rx: "2"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M12 4v4M8 14h.01M16 14h.01M9 18h6"
      }))
    };
    return /*#__PURE__*/React.createElement("svg", {
      width: "16",
      height: "16",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "#3A4A6B",
      strokeWidth: "1.7",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, p[name]);
  };
  const meters = [{
    label: "SMS Masivo",
    used: 43200,
    total: 50000,
    unit: "mensajes",
    warn: true
  }, {
    label: "WhatsApp API",
    used: 6800,
    total: 10000,
    unit: "conversaciones"
  }, {
    label: "Email Marketing",
    used: 12000,
    total: 50000,
    unit: "envíos"
  }];
  const statuses = [{
    name: "SMS Gateway",
    status: "online"
  }, {
    name: "WhatsApp API",
    status: "online"
  }, {
    name: "Email Server",
    status: "degraded"
  }, {
    name: "Chatbot Engine",
    status: "online"
  }, {
    name: "API Pública",
    status: "offline"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      border: "1px solid #EEF1F6",
      borderRadius: 12,
      padding: "14px 20px",
      marginBottom: 24,
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 9,
      background: "#FFF7E0",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#CC9200",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 6v6l4 2"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 600,
      color: "#0D1B33",
      fontSize: 13,
      margin: "0 0 1px"
    }
  }, "Tu prueba gratuita vence en 5 d\xEDas"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: 0
    }
  }, "Actualiza para mantener tus flujos de comunicaci\xF3n activos.")), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "transparent",
      color: "#0057B8",
      border: "1px solid #EEF1F6",
      padding: "7px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, "Actualizar plan")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 14,
      marginBottom: 24
    }
  }, kpis.map((k, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "18px 20px",
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    name: k.icon
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#7A8EAD"
    }
  }, k.label)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontSize: 26,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.02em"
    }
  }, k.value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: k.up ? "#15803D" : "#B91C1C",
      display: "inline-flex",
      alignItems: "center",
      gap: 2
    }
  }, k.up ? "↑" : "↓", " ", k.delta))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "22px 24px",
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Consumo del plan"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#9AACC8"
    }
  }, "Abril 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, meters.map((m, i) => {
    const pct = Math.round(m.used / m.total * 100);
    const color = m.warn ? "#D97706" : "#0057B8";
    return /*#__PURE__*/React.createElement("div", {
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 500,
        color: "#0D1B33"
      }
    }, m.label), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: "#7A8EAD",
        fontFeatureSettings: "'tnum'"
      }
    }, m.used.toLocaleString(), " / ", m.total.toLocaleString(), " ", m.unit)), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#F4F6FB",
        borderRadius: 9999,
        height: 5,
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: `${pct}%`,
        height: "100%",
        background: color,
        borderRadius: 9999
      }
    })));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "22px 24px",
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 14px"
    }
  }, "Estado del sistema"), statuses.map((s, i) => {
    const labels = {
      online: "Online",
      degraded: "Degradado",
      offline: "Offline"
    };
    const colors = {
      online: "#15803D",
      degraded: "#D97706",
      offline: "#B91C1C"
    };
    const c = colors[s.status];
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "9px 0",
        borderBottom: i < 4 ? "1px solid #F4F6FB" : "none"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "#3A4A6B"
      }
    }, s.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: c,
        display: "flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "50%",
        background: c
      }
    }), labels[s.status]));
  }))));
}
window.CelcomDashboard = Dashboard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/ExtraScreens.jsx
try { (() => {
function EmailMarketing() {
  const campaigns = [{
    name: "Newsletter abril",
    subject: "Novedades del mes",
    sent: "12.000",
    open: "42.3%",
    click: "8.1%",
    status: "Enviada",
    date: "16 abr"
  }, {
    name: "Promo Otoño",
    subject: "Hasta 30% de descuento",
    sent: "8.400",
    open: "38.9%",
    click: "6.2%",
    status: "Enviada",
    date: "10 abr"
  }, {
    name: "Bienvenida clientes",
    subject: "Te damos la bienvenida a Celcom",
    sent: "2.100",
    open: "61.0%",
    click: "14.5%",
    status: "Activa",
    date: "Recurrente"
  }, {
    name: "Encuesta NPS Q1",
    subject: "¿Cómo fue tu experiencia?",
    sent: "—",
    open: "—",
    click: "—",
    status: "Borrador",
    date: "—"
  }];
  const stColor = {
    Enviada: "#15803D",
    Activa: "#0057B8",
    Borrador: "#9AACC8"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 14,
      marginBottom: 24
    }
  }, [{
    label: "Tasa de apertura",
    value: "42.3%",
    hint: "Promedio 30 días"
  }, {
    label: "Tasa de clic",
    value: "8.1%",
    hint: "↑ 1.4% vs mes pasado"
  }, {
    label: "Rebotes",
    value: "1.2%",
    hint: "Dentro del rango"
  }, {
    label: "Desuscripciones",
    value: "0.3%",
    hint: "Saludable"
  }].map((k, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "18px 20px",
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "0 0 10px"
    }
  }, k.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontSize: 24,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.02em"
    }
  }, k.value), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#9AACC8",
      margin: "4px 0 0"
    }
  }, k.hint)))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 24px",
      borderBottom: "1px solid #EEF1F6",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Env\xEDos recientes"), /*#__PURE__*/React.createElement("button", {
    style: {
      marginLeft: "auto",
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "7px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "+ Nuevo env\xEDo")), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "#FAFBFD"
    }
  }, ["Campaña", "Asunto", "Enviados", "Apertura", "Clic", "Estado", "Fecha"].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: "left",
      padding: "11px 20px",
      fontSize: 11,
      color: "#7A8EAD",
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: ".05em"
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, campaigns.map((c, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderTop: "1px solid #F4F6FB"
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 13,
      fontWeight: 600,
      color: "#0D1B33"
    }
  }, c.name), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 13,
      color: "#7A8EAD"
    }
  }, c.subject), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 13,
      color: "#3A4A6B",
      fontFeatureSettings: "'tnum'"
    }
  }, c.sent), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 13,
      color: "#3A4A6B",
      fontFeatureSettings: "'tnum'"
    }
  }, c.open), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 13,
      color: "#3A4A6B",
      fontFeatureSettings: "'tnum'"
    }
  }, c.click), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: stColor[c.status],
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: stColor[c.status]
    }
  }), c.status)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 20px",
      fontSize: 12,
      color: "#9AACC8"
    }
  }, c.date)))))));
}
function ChatbotsHub() {
  const [view, setView] = React.useState("list"); // list | detail | onboarding | monitor
  if (view === "detail") return /*#__PURE__*/React.createElement(CelcomChatbotDetail, {
    onBack: () => setView("list")
  });
  if (view === "onboarding") return /*#__PURE__*/React.createElement(CelcomChatbotOnboarding, {
    onBack: () => setView("list")
  });
  if (view === "monitor") return /*#__PURE__*/React.createElement(CelcomChatbotMonitor, {
    onBack: () => setView("list")
  });
  const bots = [{
    name: "Asistente Farmacia Central",
    company: "Farmacia Central",
    plan: "V2",
    conv: 4412,
    cap: 5000,
    status: "Alerta"
  }, {
    name: "Soporte MegaRetail",
    company: "MegaRetail SpA",
    plan: "V2",
    conv: 4230,
    cap: 5000,
    status: "Activo"
  }, {
    name: "Agendamiento Inmob. Norte",
    company: "Inmobiliaria Norte",
    plan: "V1",
    conv: 890,
    cap: 2000,
    status: "Activo"
  }, {
    name: "Helpdesk TecnoServicios",
    company: "TecnoServicios",
    plan: "V2",
    conv: null,
    cap: 3000,
    status: "Suspendido"
  }];
  const stColor = {
    Activo: "#15803D",
    Alerta: "#D97706",
    Suspendido: "#B91C1C"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 20,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setView("monitor"),
    style: {
      background: "#fff",
      color: "#3A4A6B",
      border: "1px solid #EEF1F6",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 500,
      fontSize: 12,
      cursor: "pointer",
      fontFamily: "Inter",
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 3v18h18"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M7 14l4-4 4 4 5-5"
  })), "Monitor global"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setView("onboarding"),
    style: {
      marginLeft: "auto",
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer",
      fontFamily: "Inter",
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14M5 12h14"
  })), "Nuevo chatbot")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 14,
      marginBottom: 20
    }
  }, bots.map((b, i) => {
    const pct = b.conv ? Math.round(b.conv / b.cap * 100) : 0;
    const barColor = b.status === "Alerta" ? "#D97706" : b.status === "Suspendido" ? "#C7D2E6" : "#0057B8";
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      onClick: () => setView("detail"),
      style: {
        textAlign: "left",
        background: "#fff",
        borderRadius: 12,
        padding: "20px 22px",
        border: "1px solid #EEF1F6",
        cursor: "pointer",
        fontFamily: "Inter"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 36,
        borderRadius: 9,
        background: "#F4F6FB",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "17",
      height: "17",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "#3A4A6B",
      strokeWidth: "1.7",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("rect", {
      x: "4",
      y: "8",
      width: "16",
      height: "12",
      rx: "2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 4v4M8 14h.01M16 14h.01M9 18h6"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: "#0D1B33",
        margin: 0,
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis"
      }
    }, b.name), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 11,
        color: "#7A8EAD",
        margin: "2px 0 0"
      }
    }, b.company, " \xB7 Plan ", b.plan)), /*#__PURE__*/React.createElement("span", {
      style: {
        color: stColor[b.status],
        fontSize: 10,
        fontWeight: 500,
        display: "inline-flex",
        alignItems: "center",
        gap: 5
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "50%",
        background: stColor[b.status]
      }
    }), b.status)), /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: "1px solid #F4F6FB",
        paddingTop: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 6,
        fontSize: 11
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#7A8EAD"
      }
    }, "Consumo mensual"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#0D1B33",
        fontWeight: 600,
        fontFeatureSettings: "'tnum'"
      }
    }, b.conv ? `${b.conv.toLocaleString()} / ${b.cap.toLocaleString()}` : `— / ${b.cap.toLocaleString()}`)), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#F4F6FB",
        borderRadius: 9999,
        height: 5,
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: `${pct}%`,
        height: "100%",
        background: barColor,
        borderRadius: 9999
      }
    }))));
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => setView("onboarding"),
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: 20,
      border: "1.5px dashed #C7D2E6",
      cursor: "pointer",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 6,
      color: "#7A8EAD",
      fontSize: 13,
      fontFamily: "Inter"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      color: "#9AACC8"
    }
  }, "\uFF0B"), "Nuevo chatbot")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "\xC1rbol de conversaci\xF3n \u2014 Asistente Farmacia Central"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "2px 0 0"
    }
  }, "Vista simplificada de nodos activos.")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setView("detail"),
    style: {
      marginLeft: "auto",
      background: "none",
      border: "none",
      color: "#0057B8",
      fontSize: 12,
      fontWeight: 600,
      cursor: "pointer"
    }
  }, "Ver configuraci\xF3n \u2192")), [{
    lvl: 0,
    text: "Bienvenida — ¿en qué podemos ayudarte?"
  }, {
    lvl: 1,
    text: "1. Consultar disponibilidad de medicamento"
  }, {
    lvl: 2,
    text: "→ Solicitar nombre del medicamento"
  }, {
    lvl: 1,
    text: "2. Horarios y sucursales"
  }, {
    lvl: 2,
    text: "→ Responder desde base de conocimiento"
  }, {
    lvl: 1,
    text: "3. Hablar con un agente"
  }, {
    lvl: 2,
    text: "→ Transferir a cola humana"
  }].map((n, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "7px 0",
      paddingLeft: n.lvl * 22
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: n.lvl === 0 ? "#0057B8" : "#C7D2E6"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: n.lvl === 0 ? "#0D1B33" : "#3A4A6B",
      fontWeight: n.lvl === 0 ? 600 : 400
    }
  }, n.text)))));
}
function ApiKeys() {
  const [visible, setVisible] = React.useState({});
  const keys = [{
    label: "Production API Key",
    env: "Live",
    value: "sk_live_celcom_a1b2c3d4e5f6789012345678",
    used: "hace 2 min"
  }, {
    label: "Sandbox API Key",
    env: "Test",
    value: "sk_test_celcom_z9y8x7w6v5u4321098765432",
    used: "hace 3 h"
  }, {
    label: "Webhook Secret",
    env: "Live",
    value: "whsec_celcom_m5n4o3p2q1r0987654321abc",
    used: "hace 1 día"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Credenciales de API"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "2px 0 0"
    }
  }, "Gestiona las claves para integrar con la API de Celcom.")), /*#__PURE__*/React.createElement("button", {
    style: {
      marginLeft: "auto",
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "+ Generar clave")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, keys.map((k, i) => {
    const shown = visible[i];
    const masked = "••••••••••••" + k.value.slice(-6);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        background: "#FAFBFD",
        border: "1px solid #EEF1F6",
        borderRadius: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        fontWeight: 600,
        color: "#0D1B33"
      }
    }, k.label), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        fontWeight: 500,
        padding: "2px 7px",
        borderRadius: 9999,
        background: k.env === "Live" ? "#F4F6FB" : "#FFF7E0",
        color: k.env === "Live" ? "#3A4A6B" : "#B45309"
      }
    }, k.env)), /*#__PURE__*/React.createElement("code", {
      style: {
        fontFamily: "'Fira Code',monospace",
        fontSize: 12,
        color: "#3A4A6B"
      }
    }, shown ? k.value : masked), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 10,
        color: "#9AACC8",
        margin: "4px 0 0"
      }
    }, "Usada por \xFAltima vez ", k.used)), /*#__PURE__*/React.createElement("button", {
      onClick: () => setVisible(v => ({
        ...v,
        [i]: !v[i]
      })),
      style: {
        background: "#fff",
        border: "1px solid #EEF1F6",
        padding: "6px 10px",
        borderRadius: 6,
        fontSize: 11,
        color: "#3A4A6B",
        cursor: "pointer",
        fontWeight: 500
      }
    }, shown ? "Ocultar" : "Mostrar"), /*#__PURE__*/React.createElement("button", {
      style: {
        background: "#fff",
        border: "1px solid #EEF1F6",
        padding: "6px 10px",
        borderRadius: 6,
        fontSize: 11,
        color: "#3A4A6B",
        cursor: "pointer",
        fontWeight: 500
      }
    }, "Copiar"), /*#__PURE__*/React.createElement("button", {
      style: {
        background: "#fff",
        border: "1px solid #EEF1F6",
        padding: "6px 10px",
        borderRadius: 6,
        fontSize: 11,
        color: "#B91C1C",
        cursor: "pointer",
        fontWeight: 500
      }
    }, "Revocar"));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 14px"
    }
  }, "IPs autorizadas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, ["190.45.128.0/24 — Oficina Santiago", "181.72.56.12 — Servidor producción", "10.0.0.0/8 — VPN interna"].map((ip, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "9px 14px",
      background: "#FAFBFD",
      borderRadius: 7,
      border: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("code", {
    style: {
      fontSize: 12,
      color: "#3A4A6B",
      fontFamily: "'Fira Code',monospace"
    }
  }, ip), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "none",
      border: "none",
      color: "#9AACC8",
      cursor: "pointer",
      fontSize: 14
    }
  }, "\xD7"))))));
}
function Settings() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "220px 1fr",
      gap: 24,
      maxWidth: 1000
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, [{
    label: "Cuenta",
    active: true
  }, {
    label: "Organización"
  }, {
    label: "Miembros"
  }, {
    label: "Notificaciones"
  }, {
    label: "Integraciones"
  }, {
    label: "Seguridad"
  }].map((it, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    style: {
      textAlign: "left",
      padding: "9px 14px",
      border: "none",
      borderRadius: 7,
      background: it.active ? "#fff" : "transparent",
      border: it.active ? "1px solid #EEF1F6" : "1px solid transparent",
      fontSize: 13,
      fontWeight: it.active ? 600 : 500,
      color: it.active ? "#0D1B33" : "#7A8EAD",
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, it.label))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "24px 28px",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 15,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 4px"
    }
  }, "Perfil"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "0 0 20px"
    }
  }, "Actualiza tus datos personales."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, [{
    label: "Nombre completo",
    value: "Miguel San Martín R."
  }, {
    label: "Correo",
    value: "miguel@celcom.cl"
  }, {
    label: "Teléfono",
    value: "+56 9 8123 4567"
  }, {
    label: "Cargo",
    value: "Admin"
  }].map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: "#3A4A6B",
      display: "block",
      marginBottom: 6,
      textTransform: "uppercase",
      letterSpacing: ".04em"
    }
  }, f.label), /*#__PURE__*/React.createElement("input", {
    defaultValue: f.value,
    style: {
      width: "100%",
      padding: "9px 12px",
      borderRadius: 7,
      border: "1px solid #EEF1F6",
      background: "#FAFBFD",
      fontSize: 13,
      fontFamily: "Inter",
      color: "#0D1B33",
      boxSizing: "border-box",
      outline: "none"
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 20,
      borderTop: "1px solid #F4F6FB",
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 16px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, "Guardar cambios"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#fff",
      color: "#3A4A6B",
      border: "1px solid #EEF1F6",
      padding: "8px 16px",
      borderRadius: 7,
      fontWeight: 500,
      fontSize: 12,
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, "Cancelar"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "24px 28px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 15,
      fontWeight: 600,
      color: "#0D1B33",
      margin: "0 0 16px"
    }
  }, "Preferencias"), [{
    label: "Notificaciones por email",
    desc: "Recibe alertas cuando una campaña finalice.",
    on: true
  }, {
    label: "Resumen semanal",
    desc: "Reporte de métricas cada lunes a las 9am.",
    on: true
  }, {
    label: "Alertas de saldo bajo",
    desc: "Avisarnos cuando queden menos de 1.000 SMS.",
    on: false
  }].map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      padding: "12px 0",
      borderBottom: i < 2 ? "1px solid #F4F6FB" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "#0D1B33",
      margin: 0
    }
  }, p.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      margin: "2px 0 0"
    }
  }, p.desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 20,
      borderRadius: 9999,
      background: p.on ? "#0057B8" : "#E8EDF5",
      position: "relative",
      cursor: "pointer",
      transition: "background 150ms"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 2,
      left: p.on ? 16 : 2,
      width: 16,
      height: 16,
      borderRadius: "50%",
      background: "#fff",
      transition: "left 150ms",
      boxShadow: "0 1px 2px rgba(0,0,0,.15)"
    }
  }))))))));
}
function Billing() {
  const invoices = [{
    id: "INV-2026-04",
    period: "Abril 2026",
    amount: "$149.00",
    status: "Pagada",
    date: "01 abr"
  }, {
    id: "INV-2026-03",
    period: "Marzo 2026",
    amount: "$149.00",
    status: "Pagada",
    date: "01 mar"
  }, {
    id: "INV-2026-02",
    period: "Febrero 2026",
    amount: "$149.00",
    status: "Pagada",
    date: "01 feb"
  }, {
    id: "INV-2026-05",
    period: "Mayo 2026",
    amount: "$149.00",
    status: "Pendiente",
    date: "Vence 01 may"
  }];
  const stColor = {
    Pagada: "#15803D",
    Pendiente: "#D97706",
    Fallida: "#B91C1C"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr",
      gap: 16,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      textTransform: "uppercase",
      letterSpacing: ".06em",
      margin: "0 0 6px",
      fontWeight: 600
    }
  }, "Plan actual"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 10,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 26,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.02em"
    }
  }, "Pro"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#7A8EAD"
    }
  }, "$149 USD / mes")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "0 0 14px"
    }
  }, "Pr\xF3xima renovaci\xF3n: 1 de mayo de 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "Cambiar plan"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#fff",
      color: "#3A4A6B",
      border: "1px solid #EEF1F6",
      padding: "8px 14px",
      borderRadius: 7,
      fontWeight: 500,
      fontSize: 12,
      cursor: "pointer"
    }
  }, "Cancelar suscripci\xF3n"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      textTransform: "uppercase",
      letterSpacing: ".06em",
      margin: "0 0 6px",
      fontWeight: 600
    }
  }, "M\xE9todo de pago"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 30,
      borderRadius: 5,
      background: "#0D1B33",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontSize: 9,
      fontWeight: 700,
      letterSpacing: ".05em"
    }
  }, "VISA"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "#0D1B33",
      margin: 0,
      fontFeatureSettings: "'tnum'"
    }
  }, "\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 4242"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      margin: "2px 0 0"
    }
  }, "Vence 08/28")), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#fff",
      color: "#3A4A6B",
      border: "1px solid #EEF1F6",
      padding: "6px 12px",
      borderRadius: 6,
      fontSize: 11,
      fontWeight: 500,
      cursor: "pointer"
    }
  }, "Cambiar")))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 24px",
      borderBottom: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Historial de facturaci\xF3n")), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "#FAFBFD"
    }
  }, ["Factura", "Periodo", "Monto", "Estado", "Fecha", ""].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: "left",
      padding: "11px 24px",
      fontSize: 11,
      color: "#7A8EAD",
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: ".05em"
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, invoices.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderTop: "1px solid #F4F6FB"
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontSize: 13,
      fontWeight: 600,
      color: "#0D1B33",
      fontFamily: "'Fira Code',monospace"
    }
  }, r.id), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontSize: 13,
      color: "#3A4A6B"
    }
  }, r.period), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontSize: 13,
      color: "#3A4A6B",
      fontFeatureSettings: "'tnum'"
    }
  }, r.amount), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: stColor[r.status],
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: stColor[r.status]
    }
  }), r.status)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontSize: 12,
      color: "#7A8EAD"
    }
  }, r.date), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "none",
      border: "none",
      color: "#0057B8",
      fontSize: 12,
      fontWeight: 500,
      cursor: "pointer"
    }
  }, "Descargar PDF"))))))));
}
window.CelcomEmailMarketing = EmailMarketing;
window.CelcomChatbots = ChatbotsHub;
window.CelcomApiKeys = ApiKeys;
window.CelcomSettings = Settings;
window.CelcomBilling = Billing;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/ExtraScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/Screens.jsx
try { (() => {
function CampaignsTable() {
  const rows = [{
    name: "Promo Otoño SMS",
    channel: "SMS",
    sent: "47.320",
    delivered: "98.2%",
    status: "Enviada",
    date: "19 abr"
  }, {
    name: "Recordatorio cita",
    channel: "WhatsApp",
    sent: "3.200",
    delivered: "96.5%",
    status: "Activa",
    date: "18 abr"
  }, {
    name: "Newsletter abril",
    channel: "Email",
    sent: "12.000",
    delivered: "89.1%",
    status: "Enviada",
    date: "16 abr"
  }, {
    name: "Follow-up Ventas",
    channel: "SMS",
    sent: "800",
    delivered: "—",
    status: "Borrador",
    date: "15 abr"
  }, {
    name: "Encuesta NPS",
    channel: "WhatsApp",
    sent: "5.400",
    delivered: "94.0%",
    status: "Pausada",
    date: "12 abr"
  }];
  const stColor = {
    Enviada: "#15803D",
    Activa: "#0057B8",
    Borrador: "#9AACC8",
    Pausada: "#D97706"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 24px",
      borderBottom: "1px solid #EEF1F6",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 14,
      fontWeight: 600,
      color: "#0D1B33",
      margin: 0
    }
  }, "Campa\xF1as"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      gap: 4,
      background: "#FAFBFD",
      padding: 3,
      borderRadius: 8,
      border: "1px solid #EEF1F6"
    }
  }, ["Todas", "Activas", "Borradores"].map((t, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    style: {
      padding: "5px 12px",
      borderRadius: 6,
      border: "none",
      background: i === 0 ? "#fff" : "transparent",
      color: i === 0 ? "#0D1B33" : "#7A8EAD",
      fontSize: 12,
      fontWeight: 500,
      cursor: "pointer",
      boxShadow: i === 0 ? "0 1px 2px rgba(0,0,0,.05)" : "none"
    }
  }, t)))), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "Inter"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "#FAFBFD"
    }
  }, /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Campa\xF1a"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Canal"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Enviados"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Entrega"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Estado"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Fecha"), /*#__PURE__*/React.createElement("th", {
    style: th
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderTop: "1px solid #F4F6FB"
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: td
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "#0D1B33",
      fontWeight: 600
    }
  }, r.name)), /*#__PURE__*/React.createElement("td", {
    style: td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      background: "#F4F6FB",
      color: "#3A4A6B",
      fontSize: 11,
      fontWeight: 500,
      padding: "3px 9px",
      borderRadius: 6
    }
  }, r.channel)), /*#__PURE__*/React.createElement("td", {
    style: {
      ...td,
      fontFeatureSettings: "'tnum'"
    }
  }, r.sent), /*#__PURE__*/React.createElement("td", {
    style: {
      ...td,
      fontFeatureSettings: "'tnum'"
    }
  }, r.delivered), /*#__PURE__*/React.createElement("td", {
    style: td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: stColor[r.status],
      fontWeight: 500,
      fontSize: 12,
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: stColor[r.status]
    }
  }), r.status)), /*#__PURE__*/React.createElement("td", {
    style: {
      ...td,
      color: "#7A8EAD"
    }
  }, r.date), /*#__PURE__*/React.createElement("td", {
    style: td
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "none",
      border: "none",
      color: "#9AACC8",
      cursor: "pointer",
      fontSize: 16,
      padding: 4
    }
  }, "\u22EF"))))))));
}
const th = {
  textAlign: "left",
  padding: "11px 24px",
  fontSize: 11,
  color: "#7A8EAD",
  fontWeight: 600,
  textTransform: "uppercase",
  letterSpacing: ".05em"
};
const td = {
  padding: "14px 24px",
  fontSize: 13,
  color: "#3A4A6B"
};
function WhatsAppInbox() {
  const [active, setActive] = React.useState(0);
  const convos = [{
    name: "Juan Pérez",
    phone: "+56 9 8123 4567",
    last: "Gracias por la info",
    time: "10:42",
    unread: 2
  }, {
    name: "María González",
    phone: "+56 9 9234 5678",
    last: "¿Cuándo llega?",
    time: "10:15",
    unread: 0
  }, {
    name: "Carlos Ruiz",
    phone: "+51 9 1234 5678",
    last: "Confirmo la cita",
    time: "09:30",
    unread: 1
  }, {
    name: "Ana López",
    phone: "+52 55 5555 5555",
    last: "Perfecto",
    time: "ayer",
    unread: 0
  }];
  const msgs = [{
    me: false,
    text: "Hola, quiero información sobre sus planes",
    t: "10:38"
  }, {
    me: true,
    text: "¡Hola Juan! Claro, nuestro plan Pro incluye 50.000 SMS y WhatsApp API.",
    t: "10:39"
  }, {
    me: false,
    text: "¿Cuánto cuesta?",
    t: "10:40"
  }, {
    me: true,
    text: "$149 USD/mes. ¿Te agendo una llamada con un especialista?",
    t: "10:41"
  }, {
    me: false,
    text: "Gracias por la info",
    t: "10:42"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      background: "#FAFBFD",
      minHeight: "calc(100vh - 73px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "300px 1fr",
      gap: 0,
      background: "#fff",
      borderRadius: 12,
      border: "1px solid #EEF1F6",
      overflow: "hidden",
      height: "calc(100vh - 130px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRight: "1px solid #EEF1F6",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 16px",
      borderBottom: "1px solid #EEF1F6"
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Buscar conversaci\xF3n\u2026",
    style: {
      width: "100%",
      padding: "8px 12px",
      borderRadius: 7,
      border: "1px solid #EEF1F6",
      fontSize: 12,
      fontFamily: "Inter",
      background: "#FAFBFD",
      boxSizing: "border-box",
      outline: "none"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto"
    }
  }, convos.map((c, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActive(i),
    style: {
      width: "100%",
      padding: "12px 16px",
      border: "none",
      textAlign: "left",
      background: active === i ? "#FAFBFD" : "#fff",
      cursor: "pointer",
      borderBottom: "1px solid #F4F6FB",
      display: "flex",
      gap: 10,
      borderLeft: active === i ? "2px solid #0057B8" : "2px solid transparent"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: "50%",
      background: "#F4F6FB",
      color: "#3A4A6B",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 600,
      fontSize: 13,
      flexShrink: 0
    }
  }, c.name[0]), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: c.unread ? 600 : 500,
      color: "#0D1B33"
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: "#9AACC8"
    }
  }, c.time)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, c.last), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: "#0057B8",
      color: "#fff",
      fontSize: 9,
      fontWeight: 700,
      padding: "1px 6px",
      borderRadius: 9999
    }
  }, c.unread))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      background: "#FAFBFD"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px",
      background: "#fff",
      borderBottom: "1px solid #EEF1F6",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: "50%",
      background: "#F4F6FB",
      color: "#3A4A6B",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 600
    }
  }, convos[active].name[0]), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 600,
      fontSize: 13,
      color: "#0D1B33",
      margin: 0
    }
  }, convos[active].name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#7A8EAD",
      margin: 0
    }
  }, convos[active].phone, " \xB7 en l\xEDnea"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: 20,
      overflow: "auto",
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, msgs.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      alignSelf: m.me ? "flex-end" : "flex-start",
      maxWidth: "70%",
      background: m.me ? "#E7EEF8" : "#fff",
      color: "#0D1B33",
      padding: "9px 13px",
      borderRadius: 10,
      fontSize: 13,
      border: "1px solid #EEF1F6"
    }
  }, m.text, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: "#9AACC8",
      textAlign: "right",
      marginTop: 3
    }
  }, m.t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      background: "#fff",
      borderTop: "1px solid #EEF1F6",
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Escribe un mensaje\u2026",
    style: {
      flex: 1,
      padding: "9px 14px",
      borderRadius: 9999,
      border: "1px solid #EEF1F6",
      fontSize: 13,
      fontFamily: "Inter",
      background: "#FAFBFD",
      outline: "none"
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "9px 18px",
      borderRadius: 9999,
      fontWeight: 600,
      fontSize: 13,
      cursor: "pointer"
    }
  }, "Enviar")))));
}
window.CelcomCampaignsTable = CampaignsTable;
window.CelcomWhatsAppInbox = WhatsAppInbox;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/Sidebar.jsx
try { (() => {
function Sidebar({
  active,
  onSelect
}) {
  const groups = [{
    label: "Principal",
    items: [{
      icon: "grid",
      label: "Dashboard",
      id: "dashboard"
    }, {
      icon: "send",
      label: "Campañas",
      id: "campaigns"
    }, {
      icon: "chat",
      label: "WhatsApp",
      id: "whatsapp",
      badge: "3"
    }, {
      icon: "mail",
      label: "Email",
      id: "email"
    }, {
      icon: "bot",
      label: "Chatbots",
      id: "chatbots"
    }]
  }, {
    label: "Configuración",
    items: [{
      icon: "key",
      label: "API Keys",
      id: "api"
    }, {
      icon: "cog",
      label: "Ajustes",
      id: "settings"
    }, {
      icon: "card",
      label: "Facturación",
      id: "billing",
      dot: true
    }]
  }];
  const Icon = ({
    name,
    color
  }) => {
    const common = {
      width: 18,
      height: 18,
      stroke: color,
      fill: "none",
      strokeWidth: 1.7,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      viewBox: "0 0 24 24"
    };
    const paths = {
      grid: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "3",
        y: "3",
        width: "7",
        height: "7",
        rx: "1"
      }), /*#__PURE__*/React.createElement("rect", {
        x: "14",
        y: "3",
        width: "7",
        height: "7",
        rx: "1"
      }), /*#__PURE__*/React.createElement("rect", {
        x: "3",
        y: "14",
        width: "7",
        height: "7",
        rx: "1"
      }), /*#__PURE__*/React.createElement("rect", {
        x: "14",
        y: "14",
        width: "7",
        height: "7",
        rx: "1"
      })),
      send: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
        d: "M22 2L11 13"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M22 2l-7 20-4-9-9-4 20-7z"
      })),
      chat: /*#__PURE__*/React.createElement("path", {
        d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
      }),
      mail: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "3",
        y: "5",
        width: "18",
        height: "14",
        rx: "2"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M3 7l9 6 9-6"
      })),
      bot: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "4",
        y: "8",
        width: "16",
        height: "12",
        rx: "2"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M12 4v4M8 14h.01M16 14h.01M9 18h6"
      })),
      key: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
        cx: "8",
        cy: "15",
        r: "3"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M10.5 13L21 2.5M17 6l3 3M15 8l2 2"
      })),
      cog: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
        cx: "12",
        cy: "12",
        r: "3"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.36.16.68.4.94.71"
      })),
      card: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
        x: "2",
        y: "5",
        width: "20",
        height: "14",
        rx: "2"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M2 10h20"
      }))
    };
    return /*#__PURE__*/React.createElement("svg", common, paths[name]);
  };
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      minHeight: "100vh",
      background: "#FFFFFF",
      borderRight: "1px solid #EEF1F6",
      padding: "20px 12px",
      display: "flex",
      flexDirection: "column",
      gap: 4,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 12px 18px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      borderBottom: "1px solid #F4F6FB",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoApp || "../../assets/logo-celcom-app.jpg",
    style: {
      width: 30,
      height: 30,
      borderRadius: 7
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 15,
      fontFamily: "Poppins",
      margin: 0,
      color: "#0D1B33",
      letterSpacing: "-0.01em"
    }
  }, "celcom"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "#9AACC8",
      fontSize: 10,
      margin: 0,
      letterSpacing: ".06em",
      textTransform: "uppercase"
    }
  }, "Plataforma"))), groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.label,
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: "#9AACC8",
      fontSize: 10,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: ".08em",
      padding: "0 12px",
      margin: "0 0 6px"
    }
  }, g.label), g.items.map(it => {
    const isActive = active === it.id;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => onSelect(it.id),
      style: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 12px",
        background: isActive ? "#F4F6FB" : "transparent",
        border: "none",
        borderRadius: 8,
        cursor: "pointer",
        textAlign: "left",
        marginBottom: 1,
        position: "relative",
        transition: "background 150ms ease"
      },
      onMouseEnter: e => {
        if (!isActive) e.currentTarget.style.background = "#FAFBFD";
      },
      onMouseLeave: e => {
        if (!isActive) e.currentTarget.style.background = "transparent";
      }
    }, isActive && /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: 0,
        top: 8,
        bottom: 8,
        width: 3,
        background: "#0057B8",
        borderRadius: 2
      }
    }), /*#__PURE__*/React.createElement(Icon, {
      name: it.icon,
      color: isActive ? "#0057B8" : "#7A8EAD"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontSize: 13,
        fontWeight: isActive ? 600 : 500,
        color: isActive ? "#0D1B33" : "#3A4A6B"
      }
    }, it.label), it.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#F4F6FB",
        color: "#3A4A6B",
        fontSize: 10,
        fontWeight: 700,
        padding: "1px 7px",
        borderRadius: 9999,
        minWidth: 18,
        textAlign: "center"
      }
    }, it.badge), it.dot && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "50%",
        background: "#FFB800"
      }
    }));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      padding: "14px",
      background: "#FAFBFD",
      border: "1px solid #EEF1F6",
      borderRadius: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#3A4A6B",
      fontWeight: 600
    }
  }, "Plan Pro"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: "#7A8EAD"
    }
  }, "86%")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#EEF1F6",
      borderRadius: 9999,
      height: 4,
      overflow: "hidden",
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "86%",
      height: "100%",
      background: "#0057B8"
    }
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      width: "100%",
      background: "#0D1B33",
      color: "#fff",
      border: "none",
      padding: "7px 10px",
      borderRadius: 7,
      fontWeight: 600,
      fontSize: 11,
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, "Actualizar plan")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      paddingTop: 12,
      borderTop: "1px solid #F4F6FB",
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "12px 10px 2px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      background: "#0057B8",
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      fontWeight: 700,
      color: "#fff"
    }
  }, "M"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      color: "#0D1B33",
      fontSize: 12,
      fontWeight: 600,
      margin: 0,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, "Miguel SM"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "#9AACC8",
      fontSize: 10,
      margin: 0
    }
  }, "miguel@celcom.cl")), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#9AACC8",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 9l6 6 6-6"
  }))));
}
function Topbar({
  title,
  subtitle
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 32px",
      background: "#fff",
      borderBottom: "1px solid #EEF1F6",
      display: "flex",
      alignItems: "center",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "Poppins",
      fontSize: 20,
      fontWeight: 700,
      color: "#0D1B33",
      margin: 0,
      letterSpacing: "-0.01em"
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "#7A8EAD",
      margin: "2px 0 0"
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    style: {
      position: "absolute",
      left: 10,
      top: "50%",
      transform: "translateY(-50%)"
    },
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#9AACC8",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M21 21l-4.35-4.35"
  })), /*#__PURE__*/React.createElement("input", {
    placeholder: "Buscar\u2026",
    style: {
      padding: "8px 14px 8px 32px",
      borderRadius: 8,
      border: "1px solid #EEF1F6",
      fontSize: 13,
      width: 240,
      fontFamily: "Inter",
      background: "#FAFBFD",
      color: "#3A4A6B",
      outline: "none"
    }
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#fff",
      color: "#3A4A6B",
      border: "1px solid #EEF1F6",
      width: 36,
      height: 36,
      borderRadius: 8,
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M13.73 21a2 2 0 0 1-3.46 0"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 7,
      right: 9,
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: "#FFB800",
      border: "1.5px solid #fff"
    }
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "9px 16px",
      borderRadius: 8,
      fontWeight: 600,
      fontSize: 13,
      cursor: "pointer",
      fontFamily: "Inter",
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14M5 12h14"
  })), "Nueva campa\xF1a")));
}
window.CelcomSidebar = Sidebar;
window.CelcomTopbar = Topbar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ClientesCarousel.jsx
try { (() => {
function ClientesCarousel() {
  const clients = ["Penta Vida", "abastible", "AGUAS ANDINAS", "enjoy", "Falabella", "Ripley"];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#fff",
      padding: "50px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: "0 auto",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 24,
      fontWeight: 700,
      color: "#0D1B33",
      textAlign: "center",
      margin: "0 0 30px"
    }
  }, "Nuestros clientes"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      width: 36,
      height: 36,
      borderRadius: "50%",
      border: "none",
      background: "#FFB800",
      color: "#001F5B",
      fontSize: 16,
      fontWeight: 700,
      cursor: "pointer"
    }
  }, "\u2039"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 24
    }
  }, clients.slice(0, 4).map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 60,
      background: "#F4F6FB",
      borderRadius: 8,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "Poppins",
      fontWeight: 700,
      color: "#7A8EAD",
      fontSize: 13
    }
  }, c))), /*#__PURE__*/React.createElement("button", {
    style: {
      width: 36,
      height: 36,
      borderRadius: "50%",
      border: "none",
      background: "#FFB800",
      color: "#001F5B",
      fontSize: 16,
      fontWeight: 700,
      cursor: "pointer"
    }
  }, "\u203A"))));
}
function TestimonioSlider() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#0057B8",
      padding: "60px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: "0 auto",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 22,
      fontWeight: 700,
      color: "#fff",
      textAlign: "center",
      margin: "0 0 36px",
      lineHeight: 1.3
    }
  }, "Y estas son las experiencias que han tenido", /*#__PURE__*/React.createElement("br", null), "desde que son parte de Celcom"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      width: 40,
      height: 40,
      borderRadius: "50%",
      border: "none",
      background: "#FFB800",
      color: "#001F5B",
      fontSize: 18,
      fontWeight: 700,
      cursor: "pointer",
      flexShrink: 0
    }
  }, "\u2039"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "grid",
      gridTemplateColumns: "1fr 2fr",
      gap: 30,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: 12,
      padding: "20px 24px",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontWeight: 800,
      fontSize: 22,
      color: "#0057B8",
      margin: 0
    }
  }, "FIDELIS"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: "#7A8EAD",
      margin: "4px 0 0"
    }
  }, "Marketing Relacional")), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontSize: 18,
      fontWeight: 700,
      margin: "0 0 2px"
    }
  }, "Paula Mar\xEDn"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "rgba(255,255,255,.7)",
      margin: "0 0 10px"
    }
  }, "Jefa de proyectos Fidelis"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      lineHeight: 1.6,
      margin: 0,
      color: "rgba(255,255,255,.9)"
    }
  }, "Para nosotros, trabajar con la plataforma Celcom SMS ha sido de mucha importancia, ya que nos ha facilitado la comunicaci\xF3n hacia nuestros clientes."))), /*#__PURE__*/React.createElement("button", {
    style: {
      width: 40,
      height: 40,
      borderRadius: "50%",
      border: "none",
      background: "#FFB800",
      color: "#001F5B",
      fontSize: 18,
      fontWeight: 700,
      cursor: "pointer",
      flexShrink: 0
    }
  }, "\u203A"))));
}
window.CelcomClientesCarousel = ClientesCarousel;
window.CelcomTestimonioSlider = TestimonioSlider;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ClientesCarousel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Formulario.jsx
try { (() => {
function Formulario() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#F4F6FB",
      padding: "70px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: "0 auto",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: "center",
      fontSize: 14,
      color: "#3A4A6B",
      lineHeight: 1.6,
      margin: "0 0 8px",
      maxWidth: 600,
      marginInline: "auto"
    }
  }, "Estamos seguros de que somos el partner que est\xE1s buscando, as\xED que d\xE9janos tus datos y nuestro equipo se comunicar\xE1 contigo en menos de 24 horas. ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "#0D1B33"
    }
  }, "Es una promesa.")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 24,
      fontWeight: 700,
      color: "#0D1B33",
      textAlign: "center",
      margin: "20px 0 32px"
    }
  }, "Formulario general"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 32,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 260,
      background: "#fff",
      borderRadius: 16,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 72
    }
  }, "\uD83D\uDDA5\uFE0F"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#0057B8",
      borderRadius: 20,
      padding: "28px 26px"
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "40px 20px",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 36,
      marginBottom: 10
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "Poppins",
      fontWeight: 700,
      fontSize: 18,
      margin: "0 0 6px"
    }
  }, "\xA1Gracias!"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      margin: 0,
      opacity: .75
    }
  }, "Nos comunicaremos contigo en menos de 24 horas.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Nombre",
    style: inp
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Apellido",
    style: inp
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Tel\xE9fono",
    style: inp
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Email",
    style: inp
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Pa\xEDs",
    style: {
      ...inp,
      gridColumn: "span 2"
    }
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Empresa",
    style: inp
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Cargo",
    style: inp
  }), /*#__PURE__*/React.createElement("select", {
    style: {
      ...inp,
      gridColumn: "span 2"
    }
  }, /*#__PURE__*/React.createElement("option", null, "Servicio"), /*#__PURE__*/React.createElement("option", null, "WhatsApp API"), /*#__PURE__*/React.createElement("option", null, "SMS Masivo"), /*#__PURE__*/React.createElement("option", null, "Email Marketing"), /*#__PURE__*/React.createElement("option", null, "Chatbot")), /*#__PURE__*/React.createElement("textarea", {
    placeholder: "Mensaje",
    rows: 3,
    style: {
      ...inp,
      gridColumn: "span 2",
      resize: "none",
      fontFamily: "Inter"
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      gridColumn: "span 2",
      background: "#FFB800",
      color: "#001F5B",
      border: "none",
      padding: "11px 22px",
      borderRadius: 8,
      fontWeight: 700,
      fontSize: 14,
      cursor: "pointer",
      justifySelf: "start"
    }
  }, "Cotizar"))))));
}
const inp = {
  padding: "9px 12px",
  borderRadius: 6,
  border: "none",
  fontSize: 13,
  background: "#fff",
  color: "#0D1B33",
  fontFamily: "Inter",
  outline: "none"
};
function ChatWidget() {
  const [open, setOpen] = React.useState(true);
  if (!open) return /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(true),
    style: {
      position: "fixed",
      right: 20,
      bottom: 20,
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "#0057B8",
      color: "#fff",
      border: "none",
      fontSize: 24,
      cursor: "pointer",
      zIndex: 50,
      boxShadow: "0 8px 24px rgba(0,87,184,.3)"
    }
  }, "\uD83D\uDCAC");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 20,
      bottom: 20,
      width: 280,
      background: "#fff",
      borderRadius: 12,
      boxShadow: "0 16px 48px rgba(0,87,184,.25)",
      overflow: "hidden",
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#0057B8",
      padding: "10px 14px",
      color: "#fff",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: 13
    }
  }, "\uD83D\uDCAC Asistente Comercial Celcom"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(false),
    style: {
      background: "none",
      border: "none",
      color: "#fff",
      cursor: "pointer",
      fontSize: 16
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px",
      background: "#0057B8",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      margin: "0 0 10px"
    }
  }, "Estoy aqu\xED para ayudarte 24/7.")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 16px 20px",
      textAlign: "center",
      background: "#fff"
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#FFB800",
      color: "#001F5B",
      border: "none",
      padding: "10px 20px",
      borderRadius: 8,
      fontWeight: 700,
      fontSize: 13,
      cursor: "pointer"
    }
  }, "Iniciar conversaci\xF3n")));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "#001F5B",
      color: "#fff",
      padding: "50px 0 30px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1160,
      margin: "0 auto",
      padding: "0 32px",
      display: "grid",
      gridTemplateColumns: "1.5fr 1fr 1fr",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-celcom.svg",
    alt: "Celcom",
    style: {
      height: 22,
      filter: "brightness(0) invert(1)",
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "rgba(255,255,255,.7)",
      margin: "0 0 16px",
      lineHeight: 1.6
    }
  }, "General Holley 133, Providencia,", /*#__PURE__*/React.createElement("br", null), "Santiago, Chile."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: socialStyle
  }, "f"), /*#__PURE__*/React.createElement("a", {
    style: socialStyle
  }, "in"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 13,
      margin: "0 0 14px"
    }
  }, "Contacto"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "\uD83D\uDCE7 contacto@celcom.cl"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "\uD83D\uDCF1 +56 9 5800 3634"), /*#__PURE__*/React.createElement("p", {
    style: {
      ...footerLink,
      fontWeight: 600,
      marginTop: 14
    }
  }, "Centro de ayuda"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "\uD83D\uDCDE +56 2 2712 5911")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 13,
      margin: "0 0 14px"
    }
  }, "Servicios"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "SMS Marketing"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "WhatsApp API"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "Email Marketing"), /*#__PURE__*/React.createElement("p", {
    style: footerLink
  }, "Chatbot"), /*#__PURE__*/React.createElement("p", {
    style: {
      ...footerLink,
      marginTop: 14,
      textDecoration: "underline"
    }
  }, "T\xE9rminos y condiciones"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1160,
      margin: "30px auto 0",
      padding: "20px 32px 0",
      borderTop: "1px solid rgba(255,255,255,.1)",
      display: "flex",
      gap: 20,
      alignItems: "center",
      fontSize: 11,
      color: "rgba(255,255,255,.5)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\uD83C\uDDE8\uD83C\uDDF1 Chile"), /*#__PURE__*/React.createElement("span", null, "\uD83C\uDDF5\uD83C\uDDEA Per\xFA"), /*#__PURE__*/React.createElement("span", null, "\uD83C\uDDF2\uD83C\uDDFD M\xE9xico"), /*#__PURE__*/React.createElement("span", null, "\uD83C\uDDE8\uD83C\uDDF4 Colombia"), /*#__PURE__*/React.createElement("span", null, "\uD83C\uDDE7\uD83C\uDDF4 Bolivia")));
}
const socialStyle = {
  width: 30,
  height: 30,
  borderRadius: "50%",
  background: "rgba(255,255,255,.1)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  color: "#fff",
  fontSize: 12,
  fontWeight: 700,
  cursor: "pointer",
  textDecoration: "none"
};
const footerLink = {
  fontSize: 12,
  color: "rgba(255,255,255,.7)",
  margin: "0 0 6px",
  cursor: "pointer"
};
window.CelcomFormulario = Formulario;
window.CelcomChatWidget = ChatWidget;
window.CelcomFooter = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Formulario.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
/* global React */
const {
  useState
} = React;
function Header() {
  const [active, setActive] = React.useState("Home");
  const items = ["Home", "Servicios", "Soluciones", "Negocios", "Equipo", "Blog"];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: "#fff",
      borderBottom: "1px solid #E8EDF5",
      padding: "14px 0",
      position: "sticky",
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1160,
      margin: "0 auto",
      padding: "0 32px",
      display: "flex",
      alignItems: "center",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-celcom.svg",
    alt: "Celcom",
    style: {
      height: 26
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 24,
      marginLeft: "auto"
    }
  }, items.map(it => {
    const isActive = active === it;
    return /*#__PURE__*/React.createElement("a", {
      key: it,
      onClick: () => setActive(it),
      style: {
        fontSize: 14,
        fontWeight: 500,
        color: isActive ? "#0057B8" : "#3A4A6B",
        textDecoration: "none",
        cursor: "pointer",
        position: "relative",
        borderBottom: isActive ? "2px solid #0057B8" : "2px solid transparent",
        paddingBottom: 4
      }
    }, it, (it === "Servicios" || it === "Soluciones" || it === "Negocios") && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 4,
        fontSize: 10
      }
    }, "\u25BE"));
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#FFB800",
      color: "#001F5B",
      border: "none",
      padding: "10px 20px",
      borderRadius: 8,
      fontWeight: 700,
      fontSize: 13,
      cursor: "pointer",
      fontFamily: "Inter"
    }
  }, "Compra de cr\xE9ditos SMS")));
}
window.CelcomHeader = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#0057B8",
      padding: "80px 0",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1160,
      margin: "0 auto",
      padding: "0 32px",
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 40,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "Poppins",
      fontSize: 44,
      fontWeight: 800,
      color: "#fff",
      lineHeight: 1.15,
      margin: "0 0 28px",
      letterSpacing: "-0.01em"
    }
  }, "Somos el puente entre la comunicaci\xF3n que deseas y las herramientas que necesitas para lograrlo"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#FFB800",
      color: "#001F5B",
      border: "none",
      padding: "13px 28px",
      borderRadius: 8,
      fontWeight: 700,
      fontSize: 15,
      cursor: "pointer",
      fontFamily: "Inter",
      boxShadow: "0 4px 16px rgba(255,184,0,0.3)"
    }
  }, "Escr\xEDbenos")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 320,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 140,
      height: 260,
      background: "#0D1B33",
      borderRadius: 22,
      border: "6px solid #1a2745",
      boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
      position: "relative",
      zIndex: 3
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 10,
      left: "50%",
      transform: "translateX(-50%)",
      width: 40,
      height: 4,
      background: "#1a2745",
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "26px 14px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#FFB800",
      borderRadius: 10,
      padding: 10,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: "rgba(0,31,91,.3)",
      borderRadius: 2,
      marginBottom: 5,
      width: "70%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: "rgba(0,31,91,.3)",
      borderRadius: 2,
      width: "45%"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "rgba(255,255,255,.12)",
      borderRadius: 10,
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: "rgba(255,255,255,.3)",
      borderRadius: 2,
      marginBottom: 5,
      width: "80%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: "rgba(255,255,255,.3)",
      borderRadius: 2,
      width: "60%"
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 180,
      height: 180,
      background: "#FFB800",
      borderRadius: "42% 58% 60% 40% / 55% 40% 60% 45%",
      left: "45%",
      top: "15%",
      opacity: .9,
      zIndex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 40,
      height: 40,
      background: "#FFD966",
      borderRadius: "50%",
      right: "12%",
      top: "20%",
      zIndex: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 24,
      height: 24,
      background: "#fff",
      borderRadius: "50%",
      right: "22%",
      top: "45%",
      zIndex: 2,
      opacity: .95
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 30,
      height: 18,
      background: "#FFB800",
      borderRadius: 4,
      left: "12%",
      top: "35%",
      transform: "rotate(-20deg)",
      zIndex: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 44,
      height: 44,
      background: "#fff",
      borderRadius: "50%",
      right: "8%",
      bottom: "20%",
      zIndex: 2,
      opacity: .9
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 24,
      height: 24,
      background: "#FFB800",
      borderRadius: "50%",
      left: "18%",
      bottom: "18%",
      zIndex: 2
    }
  }))));
}
window.CelcomHero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/QuienesSomos.jsx
try { (() => {
function QuienesSomos() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#fff",
      padding: "80px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: "0 auto",
      padding: "0 32px",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 30,
      fontWeight: 700,
      color: "#0D1B33",
      margin: "0 0 50px"
    }
  }, "\xBFQui\xE9nes somos?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 60,
      alignItems: "center",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 280
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 150,
      height: 150,
      background: "#E8EDF5",
      borderRadius: "60% 40% 55% 45%",
      zIndex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 30,
      top: 20,
      width: 150,
      height: 110,
      background: "#f5f5f5",
      borderRadius: 12,
      zIndex: 2,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#9AACC8",
      fontSize: 12
    }
  }, "[Imagen equipo]"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: 0,
      bottom: 0,
      width: 180,
      height: 180,
      background: "#FFB800",
      borderRadius: "50% 50% 40% 60%",
      zIndex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: 20,
      bottom: 20,
      width: 170,
      height: 140,
      background: "#f5f5f5",
      borderRadius: 12,
      zIndex: 2,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#9AACC8",
      fontSize: 12
    }
  }, "[Imagen cliente]")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: "#3A4A6B",
      lineHeight: 1.7,
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "#0D1B33",
      fontWeight: 700
    }
  }, "Celcom"), " es un integrador m\xF3vil de valor agregado que ofrece plataformas bidireccionales de contactabilidad basadas en mensajer\xEDa ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "#0D1B33"
    }
  }, "A2P"), " (aplicativo\u2013persona) en ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "#0D1B33"
    }
  }, "SMS, WhatsApp API, Email Marketing, VMS y Chatbots"), "."))));
}
function PromesaBanner({
  variant = "blue"
}) {
  const isBlue = variant === "blue";
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: isBlue ? "#0057B8" : "#FFB800",
      padding: "40px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: "0 auto",
      padding: "0 32px",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: isBlue ? "#fff" : "#001F5B",
      lineHeight: 1.6,
      margin: "0 0 14px"
    }
  }, isBlue ? "Nos hemos comprometido" : "Si no sabes cuál es la solución ideal", " ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, isBlue ? "con no solo acompañar a nuestros clientes en la implementación de las herramientas; también queremos que puedan sacar el mayor provecho de ellas." : "para lograr la meta que te has planteado como empresa, no te preocupes. De acuerdo a tu objetivo tenemos soluciones ideales para cumplirlo."))));
}
window.CelcomQuienesSomos = QuienesSomos;
window.CelcomPromesaBanner = PromesaBanner;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/QuienesSomos.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ServiciosTabs.jsx
try { (() => {
function ServiciosTabs() {
  const [active, setActive] = React.useState(0);
  const tabs = [{
    icon: "💬",
    name: "Whatsapp API",
    title: "WhatsApp API Business",
    desc: "Conecta con tus clientes a través de la app de mensajería más utilizada en el mundo con las ventajas de la versión business.",
    cta: "Quiero usarla"
  }, {
    icon: "📱",
    name: "SMS Masivo",
    title: "SMS Masivo",
    desc: "Envía mensajes de texto a miles de clientes en segundos. Ideal para alertas, promociones y confirmaciones.",
    cta: "Quiero usarlo"
  }, {
    icon: "✉️",
    name: "Email Marketing",
    title: "Email Marketing",
    desc: "Campañas de correo con segmentación avanzada, plantillas y analítica en tiempo real.",
    cta: "Quiero usarlo"
  }, {
    icon: "🤖",
    name: "Chatbot",
    title: "Chatbots inteligentes",
    desc: "Automatiza respuestas, agenda citas y deriva a un agente humano cuando haga falta.",
    cta: "Quiero uno"
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#fff",
      padding: "60px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1160,
      margin: "0 auto",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 28,
      fontWeight: 700,
      color: "#0D1B33",
      textAlign: "center",
      margin: "0 0 40px"
    }
  }, "Estos son nuestros servicios"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "240px 1fr",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, tabs.map((t, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActive(i),
    style: {
      textAlign: "left",
      padding: "14px 16px",
      border: "none",
      cursor: "pointer",
      background: active === i ? "#FAFBFF" : "transparent",
      borderLeft: active === i ? "3px solid #0057B8" : "3px solid transparent",
      fontSize: 14,
      fontWeight: active === i ? 700 : 500,
      color: active === i ? "#0057B8" : "#3A4A6B",
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontFamily: "Inter",
      borderBottom: "1px solid #E8EDF5"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14
    }
  }, t.icon), t.name))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#E8EDF5",
      borderRadius: 16,
      padding: 40,
      display: "flex",
      gap: 24,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 22,
      fontWeight: 700,
      color: "#0D1B33",
      margin: "0 0 12px"
    }
  }, tabs[active].title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: "#3A4A6B",
      lineHeight: 1.6,
      margin: "0 0 20px"
    }
  }, tabs[active].desc), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "transparent",
      color: "#FFB800",
      border: "none",
      fontWeight: 700,
      fontSize: 13,
      cursor: "pointer",
      padding: 0
    }
  }, tabs[active].cta, " \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 220,
      height: 180,
      background: "#fff",
      borderRadius: 12,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 64
    }
  }, tabs[active].icon)))));
}
function SolucionesGrid() {
  const solutions = [{
    title: "Marketing",
    desc: "Queremos que puedas dar a conocer tus campañas creativas a través de herramientas precisas y confiables.",
    cta: "Quiero posicionar",
    emoji: "📢",
    bg: "#FFF6E0"
  }, {
    title: "Ventas",
    desc: "Si estás buscando que tus ingresos incrementen y darle al omnicanal que necesitas, llegaste al lugar correcto.",
    cta: "Quiero vender",
    emoji: "📈",
    bg: "#FFF6E0"
  }, {
    title: "Atención al cliente",
    desc: "Responder a tu cliente ágil y eficientemente es algo que puedes lograr sin importar la hora o el lugar.",
    cta: "Quiero mejorar",
    emoji: "🎧",
    bg: "#FFF6E0"
  }, {
    title: "Tecnología",
    desc: "Si lo que necesitas es automatizar tu comunicación a través de plataformas efectivas y analíticas, sabemos cómo.",
    cta: "Quiero eficientar",
    emoji: "⚙️",
    bg: "#FFF6E0"
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#fff",
      padding: "60px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: "0 auto",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "Poppins",
      fontSize: 28,
      fontWeight: 700,
      color: "#0D1B33",
      textAlign: "center",
      margin: "0 0 40px"
    }
  }, "Nuestras soluciones"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20
    }
  }, solutions.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#fff",
      border: "1px solid #E8EDF5",
      borderRadius: 16,
      padding: "24px 28px",
      boxShadow: "0 2px 8px rgba(0,87,184,.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: s.bg,
      borderRadius: 12,
      width: "100%",
      height: 150,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 72,
      marginBottom: 16
    }
  }, s.emoji), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "Poppins",
      fontSize: 20,
      fontWeight: 700,
      color: "#0D1B33",
      margin: "0 0 8px"
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "#7A8EAD",
      lineHeight: 1.5,
      margin: "0 0 16px"
    }
  }, s.desc), /*#__PURE__*/React.createElement("button", {
    style: {
      background: "#0057B8",
      color: "#fff",
      border: "none",
      padding: "8px 16px",
      borderRadius: 8,
      fontWeight: 600,
      fontSize: 12,
      cursor: "pointer"
    }
  }, s.cta, " \u2192"))))));
}
window.CelcomServiciosTabs = ServiciosTabs;
window.CelcomSolucionesGrid = SolucionesGrid;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ServiciosTabs.jsx", error: String((e && e.message) || e) }); }

__ds_ns.DesignSystem = __ds_scope.DesignSystem;

})();
